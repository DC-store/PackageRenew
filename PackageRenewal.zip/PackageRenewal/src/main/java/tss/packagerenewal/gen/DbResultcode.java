package tss.packagerenewal.gen;

import java.util.HashMap;

import org.springframework.stereotype.Component;

@Component
public class DbResultcode {
   
	
	
	public static String errorcode(int errorCode){
	 
	   HashMap <Integer,String> map = new HashMap <>();
	   map.put(0, "SUCCESSFUL_RESPONSE_FROM_API");
	   map.put(1, "AUTHENTICATION_FAILED" );
	   map.put(2, "AUTHORIZATION_FAILED");
	   map.put(3, "ERROR_IN_PROCESSING_REQUEST_PARAMETERS");
	   map.put(4, "MANDATORY_PARAMETER_MISSING");
	   map.put(5, "SUBSCRIBER_ALREADY_PRESENT");
	   map.put(6, "SUBSCRIBER_NOT_PRESENT");
	   map.put(7, "NEW_MAC_ADDRESS_ALREADY_PRESENT");
	   map.put(8, "DUPLICATE_TRANSACTION_ID");
	   map.put(10, "DB_ERROR_WHILE_PROCESSING_THE_API");
	   map.put(101, "INVALID_SUBSCRIBER_ID");
	   map.put(102, "INVALID_SERVICE_ID");
	   map.put(103, "INVALID_MAC_ADDRESS");
	   map.put(104, "INVALID_SERVICE_NUMBER");
	   map.put(105, "INVALID_SERVICE_TYPE_ID");
	   map.put(106, "INVALID_CITY_ID");
	   map.put(107, "INVALID_DISCTRICT_ID");
	   map.put(108, "INVALID_NEIGHBOURHOOD_ID");
	   map.put(109, "INVALID_STREET_ID");
	   map.put(110, "INVALID_TARIFF_TYPE_ID/PACKAGE_ID");
	   map.put(111, "INVALID_CMTSOLT_ID");
	   map.put(151, "CITY_ID_NOT_PRESENT");
	   map.put(152, "DISTRICT_ID_NOT_PRESENT");
	   map.put(153, "TARIFF_TYPE/PACKAGE_NOT_PRESENT");
	   
	   String description = map.get(errorCode);
	   return description;
	   
	 
       }
	}
	
//public class Resultcode {
//
//	public static void main(String[] args) {
//  
//		ResultDesp myObj = new ResultDesp();
//		int resultcode = 101;
//		
//		System.out.println(myObj.errorcode(resultcode));
//		
//	}

