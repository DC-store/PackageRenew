package tss.packagerenewal.gen;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class GenericValidations {

	static LoggingUtils logger = new LoggingUtils(GenericValidations.class.getName());

	public int MacValidation(String macAdress, int minlength, int maxlength, int optional, String txn) {

		String macAdressregex = "^[A-Za-z 0-9 \\:\\@\\-]{" + minlength + "," + maxlength + "}$";
		Pattern patternMacAdress = Pattern.compile(macAdressregex);
		if (optional == 0) {
			if ((macAdress.length() == 0) || macAdress.contains("00:00:00:00:00")) {
				logger.error(
						"txn::" + txn + " func:MacValidation ::param::" + macAdress + " desc :: mac address ::null");
				return 0;
			}
		}
		Matcher matcherMacAdress = patternMacAdress.matcher(macAdress);

		if (matcherMacAdress.matches() == true) {

			return 1;
		} else {

			return 0;
		}
	}

	public int AddrValidator(String Address, int minlength, int maxlength, int optional, String txn) {

		String Adressregex = "^[A-Za-z]{" + minlength + "," + maxlength + "}$";

		Pattern patternAddress = Pattern.compile(Adressregex);

		Matcher matcherAddress = patternAddress.matcher(Address);

		int x = 0;
		if (optional == 0 || (optional == 1 && Address != null)) {

			if (matcherAddress.matches() == true) {
				x = 1;

			} else {
				x = 0;

			}

		}
		return x;

	}

	// validating numberID--> SubscriberID, ServiceID, ServiceTypeId, GIProfileId, CityId, DistrictId,
//	NeigbourhoodID,StreetID,QuotaDuration,ServiceNo
// CmtsOltId, serviceTourId,subscriberTourID
	public int numberValidator(int numberId, int minlength, int maxlength, int optional, String txn) {
		int numValidatorResult = 0;
		if (numberId != 0) {
			String NumberID = String.valueOf(numberId);
			String regexNumberID = "^[0-9]{" + minlength + "," + maxlength + "}$";

			Pattern patternNumberID = Pattern.compile(regexNumberID);

			Matcher matcherNumberID = patternNumberID.matcher(NumberID);

			if (optional == 0 || (optional == 1 && NumberID != null)) {

				if (matcherNumberID.matches() == true) {
					numValidatorResult = 1;
				} else {
					numValidatorResult = 0;
				}

			}
		}
		return numValidatorResult;
	}

	public int numberValidatorString(String NumberID, int minlength, int maxlength, int optional, String txn) {
		int numValidatorResult = 0;

		if (NumberID == "" || NumberID.isEmpty()) {
			return numValidatorResult;
		}

		String regexNumberID = "^[0-9]{" + minlength + "," + maxlength + "}$";

		Pattern patternNumberID = Pattern.compile(regexNumberID);

		Matcher matcherNumberID = patternNumberID.matcher(NumberID);

		if (optional == 0 || (optional == 1 && NumberID != null)) {

			if (matcherNumberID.matches() == true) {
				numValidatorResult = 1;
			} else {
				numValidatorResult = 0;
			}

		}
		return numValidatorResult;
	}

	// Validating Date And Time in the format yyyy-mm-dd hh:mm for StartTime And EndTime
	public int dateAndTimeValidation(String dateAndTime, int minlength, int maxlength, int optional, String txn) {

		String regexDateAndTime = "^\\d{4}-[01]\\d-[0-3]\\d\\s(\\d){2}:(\\d){2}{" + minlength + "," + maxlength + "}$";

		Pattern patternDateAndTime = Pattern.compile(regexDateAndTime);

		Matcher matcherDateAndTime = patternDateAndTime.matcher(dateAndTime);

		int x = 0;
		if (optional == 0 || (optional == 1 && dateAndTime != null)) {

			if (matcherDateAndTime.matches() == true) {
				x = 1;

			} else {
				x = 0;
			}
		}
		return x;
	}

	// Validating for StaticIPUser
	public int ipAddressValidator(String IpAddress, int minlength, int maxlength, int optional, String txn) {

		String regexIpAddress = "^\\d{1,3}.\\d{1,3}.\\d{1,3}.\\d{1,3}{" + minlength + "," + maxlength + "}$";

		Pattern patternIpAddress = Pattern.compile(regexIpAddress);

		Matcher matcherIpAddress = patternIpAddress.matcher(IpAddress);

		int x = 0;
		if (optional == 0 || (optional == 1 && IpAddress != null)) {

			if (matcherIpAddress.matches() == true) {
				x = 1;
			} else {
				x = 0;
			}
		}
		return x;
	}

	// iPV6 VALIDATOR

	public int ipAddressV6Validator(String IpAddress, int minlength, int maxlength, int optional, String txn) {

		String regexIpAddress = "^[A-Za-z 0-9 /:/.]{" + minlength + "," + maxlength + "}$";

		Pattern patternIpAddress = Pattern.compile(regexIpAddress);

		Matcher matcherIpAddress = patternIpAddress.matcher(IpAddress);

		int x = 0;
		if (optional == 0 || (optional == 1 && IpAddress != null)) {

			if (matcherIpAddress.matches() == true) {
				x = 1;
			} else {
				x = 0;
			}
		}
		return x;
	}

//ONLY DATEVALIDATOR

	public int dateValidation(String date, int minlength, int maxlength, int optional) {

		String regexDate = "^\\d{4}-[01]\\d-[0-3]\\d{" + minlength + "," + maxlength + "}$";

		Pattern patternDate = Pattern.compile(regexDate);

		Matcher matcherDate = patternDate.matcher(date);

		int x = 0;
		if (optional == 0 || (optional == 1 && date != null)) {

			if (matcherDate.matches() == true) {
				x = 1;
			} else {
				x = 0;
			}
		}
		return x;
	}

	public int NameValidation(String NameValidator, int minlength, int maxlength, int optional, String txn) {

		int x = 0;

		if (NameValidator == "" || NameValidator.isEmpty()) {
			return x;
		}
		String NameValidatorregex = "^[A-Za-z 0-9 /_/s/-]{" + minlength + "," + maxlength + "}$";

		Pattern patternNameValidator = Pattern.compile(NameValidatorregex);

		Matcher matcherNameValidator = patternNameValidator.matcher(NameValidator);

		if (optional == 0 || (optional == 1 && NameValidator != null)) {
			if (matcherNameValidator.matches() == true) {
				x = 1;
			} else {
				x = 0;
			}
		}
		return x;
	}
	public int QuotaValidatorString(String NumberID, int minlength, int maxlength, int optional, String txn) {
		int numValidatorResult = 0;

		if (NumberID == "") {
			numValidatorResult = 0;
			return numValidatorResult;
		}

		if (NumberID.equals("TRUE") || NumberID.equals("FALSE")) {

			numValidatorResult = 1;
			return numValidatorResult;
		}

		String regexNumberID = "^[0-9]{" + minlength + "," + maxlength + "}$";

		Pattern patternNumberID = Pattern.compile(regexNumberID);

		Matcher matcherNumberID = patternNumberID.matcher(NumberID);

		if (optional == 0 || (optional == 1 && NumberID != null)) {

			if (matcherNumberID.matches() == true) {
				numValidatorResult = 1;
			} else {
				numValidatorResult = 0;
			}

		}

		return numValidatorResult;

	}
}
