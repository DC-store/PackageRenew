package tss.packagerenewal.gen;




import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import tss.packagerenewal.Services.EvrService;

public class UtilMethod {
	 private static LoggingUtils logger = new LoggingUtils((EvrService.class.getName()));	

    public String readVal(String FileName, String param) {
    	System.out.println("FileName  :" + FileName);
        String val = "";
        File file = new File(FileName);
        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line = "";

            while ((line = reader.readLine()) != null) {
                if (line.trim().startsWith(param)) {
                    val = line.substring(line.indexOf("=") + 1, line.length());
                    val = val.replaceAll("\\s", "");
                }
            }
            val = val.replaceAll("\\s", "");
            if (reader != null) {
                reader.close();
            }
        } catch (Exception e) {
            logger.warn("Exception in method readVal - Class UtilMethod : " + e);
        }
        return val;
    }

    public synchronized void evrCreateFile(File filePath) throws IOException {

        try {
            File file = filePath;
            file.createNewFile();
            System.out.println("------------------------------1------------------------------------");
            logger.info("Successfully created the file :");
            System.out.println("--------------------------------2------------------------------------");
        } catch (IOException e) {
            logger.warn("Exception in method evrCreateFile() - Class UtilMethod : " + e);
        }
    }

    public synchronized void evrFileWriter(File filePath, String strBean) throws IOException {

        try {
            FileWriter myWriter = new FileWriter(filePath, true);
            myWriter.write(strBean + System.lineSeparator());
            myWriter.close();
            logger.info("Successfully wrote to the file :");
        } catch (IOException e) {
            logger.warn("Exception in method evrFileWriter() - Class UtilMethod : " + e);
        }
    }
}


