package tss.packagerenewal.gen;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.util.Map;

public class ResultCodeMapping {

    private static ResultCodeMapping resultCodeMapping = null;
    private static Map<Integer, String> mapResultCode  = new HashMap<Integer, String>();

    // To Create singleton
    static {
        resultCodeMapping = new ResultCodeMapping();
    }
    public static ResultCodeMapping getResultCodeMappingObj() {
        return resultCodeMapping;
    }

    // Private Constructor
    private ResultCodeMapping(){
        ReadConfigFile();
    }

    public void ReadConfigFile(){
        String filePath = System.getenv("PRODUCT_CONFIG_PATH");
        String FileName = filePath + File.separator + "ResultCodeMapping.cfg";
        BufferedReader br = null;

        try {
            File file = new File(FileName);
            br = new BufferedReader(new FileReader(file));
            String line = null;

            while ((line = br.readLine()) != null) {
                String[] parts = line.split("=");
                Integer code = Integer.parseInt(parts[0].trim());
                String number = parts[1].trim();

                if (!code.equals("") && !number.equals(""))
                    mapResultCode.put(code, number);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (br != null) {
                try {
                    br.close();
                } catch (Exception e) {
                }
            }
        }
        return;
    }

    public static String getErrorCodeDescription(int errorCode) {
        String description = mapResultCode.get(errorCode);
        return description;
    }
}