package tss.packagerenewal.gen;

public class APINames {
	public static final int API_ADD_SUBSCRIBER = 101;
	public static final int API_ADD_OR_REMOVE_ADDON = 102;
	public static final int API_DEFINE_TIME_BASED_QUOTA = 103;
	public static final int API_DEFINE_SECURE_INTRNT_PROFILE = 104;
	public static final int API_DELETE_SUBS_SERVICE = 105;
	public static final int API_QUOTA_COUNTER_INQUIRY = 106;
	public static final int API_QUOTA_COUNTER_SET = 107;
	public static final int API_QUOTA_HISTORY_LISTING = 108;
	public static final int API_SERVICE_QUERY = 109;
	public static final int API_SUBS_ADDON_INQUIRY = 110;
	public static final int API_SUBS_IP_QUERY_v4 = 111;
	public static final int API_SUBS_IP_QUERY_v6 = 112;
	public static final int API_SUBS_MAC_QUERY_v4 = 113;
	public static final int API_SUBS_MAC_QUERY_v6 = 114;
	public static final int API_SUBS_MODEM_COPY = 115;
	public static final int API_SUBS_SERVICE_QUERY = 116;
	public static final int API_SUBS_UPDATE = 117;
	public static final int API_SERVICE_TURN_ON_OFF = 118;
	public static final int API_WARN_OF_DEBT = 119;
	public static final int API_GET_TRANSACTION_STATUS = 120;
	public static final int API_RENEWAL_SERVICE = 121;
	
}

