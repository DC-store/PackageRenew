package tss.packagerenewal.gen;

public class ErrorCodes {
    public static final int SUCCESSFUL_RESPONSE_FROM_API = 0;

    public static final int AUTHENTICATION_FAILED = 1;

    public static final int AUTHORIZATION_FAILED = 2;

    public static final int ERROR_IN_PROCESSING_REQUEST_PARAMETERS = 3;

    public static final int MANDATORY_PARAMETER_MISSING = 4;

    public static final int SUBSCRIBER_ALREADY_PRESENT = 5;
    public static final int SUBSCRIBER_NOT_PRESENT = 6;
    public static final int NEW_MAC_ADDRESS_ALREADY_PRESENT = 7;

    public static final int DUPLICATE_TRANSACTION_ID = 8;

    public static final int DB_ERROR_WHILE_PROCESSING_THE_API = 10;
	public static final int SYSTEM_ERROR = 11;

	public static final int MANDATORY_PARAMETER_SUBS_ID_MISSING = 21;
	public static final int MANDATORY_PARAMETER_SERV_ID_MISSING = 22;
	public static final int MANDATORY_PARAMETER_ADDON_VAL_MISSING = 23;
	public static final int MANDATORY_PARAMETER_SERV_NO_MISSING = 24;
	public static final int MANDATORY_PARAMETER_SERV_TYPE_ID_MISSING = 25;
	public static final int MANDATORY_PARAMETER_CITY_ID_MISSING = 26;
	public static final int MANDATORY_PARAMETER_DISTRICT_ID_MISSING = 27;
	public static final int MANDATORY_PARAMETER_NEIGHD_ID_MISSING = 28;
	public static final int MANDATORY_PARAMETER_STREET_ID_MISSING = 29;
	public static final int MANDATORY_PARAMETER_TARIFF_ID_MISSING = 30;
	public static final int MANDATORY_PARAMETER_CMTS_OLT_ID_MISSING = 31;
	public static final int MANDATORY_PARAMETER_IP_ADDR_MISSING = 32;
	public static final int MANDATORY_PARAMETER_IP_VERSION_MISSING = 33;
	public static final int MANDATORY_PARAMETER_SECURE_INT_PROFILE_MISSING = 34;
	public static final int MANDATORY_PARAMETER_ADDON_MISSING = 35;
	public static final int MANDATORY_PARAMETER_OLD_MAC_MISSING = 36;
	public static final int MANDATORY_PARAMETER_NEW_MAC_MISSING = 37;
	public static final int MANDATORY_PARAMETER_MAC_OR_USER_MISSING = 38;
	public static final int MANDATORY_PARAMETER_OPERATION_NAME_MISSING = 39;
	public static final int MANDATORY_PARAMETER_SET_VAL_TAG_MISSING = 40;
	public static final int MANDATORY_PARAMETER_QUOTA_DURATION_MISSING = 41;
	public static final int MANDATORY_PARAMETER_INCOMING_QUOTA_MISSING = 42;
	public static final int MANDATORY_PARAMETER_OUTGOING_QUOTA_MISSING = 43;
	public static final int MANMANDATORY_PARAMETER_TRANSACTIONID_MISSING = 44;
	public static final int TIME_OUT_ERROR = 50;
	public static final int FAILURE = 51;

	//	public static final int SUCCESS = 52;
	public static final int PROCESSING = 53;
	public static final int FAILURE_SUBSCRIBER_TYPE_NOT_MATCHING_WITH_PACKAGE = 54;
	public static final int PROVISIONING_FAILED = 55;
	public static final int FAILURE_REPETITION_NOT_ALLOWED = 56;
	public static final int RENEWAL_NOT_ALLOWED = 57;
	public static final int FAILURE_VALIDITY_EXTENSION_NOT_ALLOWED = 59;
	public static final int FAILURE_PACKAGE_IS_IN_EXCEPTION_LIST = 58;
	public static final int PREVIOUS_REQUEST_IS_PENDING = 60;
	public static final int FAILURE_TIME_OUT_DETECTED_TIME_MISS_MATCH = 61;

	public static final int INVALID_SUBSCRIBER_ID = 101;

    public static final int INVALID_SERVICE_ID = 102;

    public static final int INVALID_MAC_ADDRESS = 103;
    public static final int INVALID_SERVICE_NUMBER = 104;
    public static final int INVALID_SERVICE_TYPE_ID = 105;
    public static final int INVALID_CITY_ID = 106;
    public static final int INVALID_DISCTRICT_ID = 107;
    public static final int INVALID_NEIGHBOURHOOD_ID = 108;
    public static final int INVALID_STREET_ID = 109;
    public static final int INVALID_TARIFF_TYPE_ID_PACKAGE_ID = 110;
    public static final int INVALID_CMTSOLT_ID = 111;
    public static final int INVALID_IP_Address = 112;
    public static final int INVALID_IP_Flag = 113;
    public static final int INVALID_PROFILE_ID = 114;
    public static final int INVALID_PACKAGE_NAME = 115;
    public static final int INVALID_DEGER_VALUE = 116;
    public static final int INVALID_OPERATION_NAME = 117;
    public static final int INVALID_SET_VALUE = 118;
    public static final int INVALID_QUOTADURATION_VALUE = 119;
    public static final int INVALID_INCOMINGDATA_VALUE = 120;
    public static final int INVALID_OUTGOINGDATA_VALUE = 121;
    public static final int INVALID_TRANSACTION_ID = 122;

    public static final int CITY_ID_NOT_PRESENT = 151;

    public static final int DISTRICT_ID_NOT_PRESENT = 152;
    public static final int TARIFF_TYPE_PACKAGE_NOT_PRESENT = 153;

    public static final int SECURE_INTERNET_PROFILE_NOT_FOUND = 154;

    public static final int PACKAGE_ALREADY_SUBSCRIBED = 155;

    public static final int BTKCLOSED_IS_ALREADY_ACTIVE = 156;

    public static final int BTKCLOSED_IS_ALREADY_INACTIVE = 157;

    public static final int OUTOFDEBT_IS_ALREADY_ACTIVE = 158;

    public static final int OUTOFDEBT_IS_ALREADY_INACTIVE = 159;
}
