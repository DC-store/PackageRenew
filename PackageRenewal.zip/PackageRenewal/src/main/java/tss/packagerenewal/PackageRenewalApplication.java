package tss.packagerenewal;

import java.util.Timer;
import java.util.TimerTask;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.yaml.snakeyaml.comments.CommentLine;

import tss.packagerenewal.Services.PackageRenewalService;
@EnableScheduling
@SpringBootApplication
public class PackageRenewalApplication  {

public static int tableId ;
	
	public static void main(String[] args)  {

		SpringApplication.run(PackageRenewalApplication.class, args);
		
	
		
		
	}
}



