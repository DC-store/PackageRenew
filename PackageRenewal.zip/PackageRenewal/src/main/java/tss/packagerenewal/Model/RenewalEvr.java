package tss.packagerenewal.Model;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "bb_evr_provisioning_renewal")
public class RenewalEvr {
	// @Id
	// @Column(name = "renewalEvrId")
	// private Long renewalEvrId;

	@Id
	@Column(name = "TRANSACTION_ID")
	private String transactionId;

	@Column(name = "OldMac")
	private String oldMac;

	@Column(name = "NewMac")
	private String newMac;

	@Column(name = "AddOnName")
	private String addOnName;

	@Column(name = "AddOnValue")
	private String addOnValue;

	@Column(name = "Mac_Username")
	private String macUsername;

	@Column(name = "ServiceOperation")
	private String serviceOperation;

	@Column(name = "IncomingData")
	private Long incomingData;

	@Column(name = "OutgoingData")
	private Long outgoingData;

	@Column(name = "ServiceNo")
	private String serviceNo;

	@Column(name = "CityID")
	private Integer cityID;

	@Column(name = "DistrictID")
	private Integer districtID;

	@Column(name = "NeighborhoodID")
	private Integer neighborhoodID;

	@Column(name = "StreetID")
	private Integer streetID;

	@Column(name = "CmtsOLTID")
	private Integer cmtsOLTID;

	@Column(name = "SecureInternetProfileID")
	private Long secureInternetProfileID;

	@Column(name = "Ipv4")
	private String ipv4;

	@Column(name = "Ipv6")
	private String ipv6;

	@Column(name = "SEQ_NO")
	private Long sEQNO;

	@Column(name = "SUB_IDENTIFIER")
	private String subIdentifier;

	@Column(name = "ACCOUNT_ID")
	private String accountId;

	@Column(name = "SUBSCRIBER_ID")
	private Long subscriberId;

	@Column(name = "IMEI")
	private String imei;

	@Column(name = "IMSI")
	private String imsi;

	@Column(name = "SUBSCRIPTION_TYPE")
	private Long subscriptionType;

	@Column(name = "CUSTOMER_TYPE")
	private String customerType;

	@Column(name = "COS_ID")
	private String cosId;

	@Column(name = "APPLICATION_ID")
	private Long applicationId;

	@Column(name = "CDR_TYPE")
	private Long cdrType;

	private LocalDateTime TIMESTAMP;
	private LocalDateTime SERVICE_START_TIME;
	private LocalDateTime SERVICE_END_TIME;

	@Column(name = "SESSION_ID")
	private String sessionId;

	@Column(name = "SGSN_IP")
	private String sgsnIp;

	@Column(name = "SGSN_MCC_MNC")
	private String sgsnMccMnc;

	@Column(name = "SGSN_TADIG")
	private String sgsnTadig;

	@Column(name = "APN")
	private String apn;

	@Column(name = "LOCATION_ACCESS")
	private String locationAccess;

	@Column(name = "ACCESS_TYPE")
	private Long accessType;

	@Column(name = "CHARGING_ID")
	private String chargingId;

	@Column(name = "RATING_GROUP")
	private Long ratingGroup;

	@Column(name = "SERVICE_IDENTIFIER")
	private String serviceIdentifier;

	@Column(name = "PACKAGE_ID")
	private String packageId;

	@Column(name = "BUCKET_ID")
	private String bucketId;

	@Column(name = "SERVICE_REQ_COUNT")
	private Long serviceReqCount;

	@Column(name = "CHARGE_USED")
	private Long chargeUsed;

	@Column(name = "OTHER_SUB_IDENTIFIER")
	private String otherSubIdentifier;

	@Column(name = "RESULT_CODE")
	private Integer resultCode;

	@Column(name = "IN_REFERENCE_ID")
	private String inReferenceId;

	@Column(name = "DOWNLINK_K_BYTES")
	private Long downlinkKBytes;

	@Column(name = "UPLINK_K_BYTES")
	private Long uplinkKBytes;

	@Column(name = "ACTUAL_COMM_USED_REF")
	private String actualCommUsedRef;

	@Column(name = "TOTAL_COMM_ACCOUNTED")
	private Long totalCommAccounted;

	@Column(name = "COMM_TYPE")
	private Long commType;

	@Column(name = "CHARGE")
	private Long charge;

	@Column(name = "TOTAL_TAX")
	private Long totalTax;

	@Column(name = "RESERVED_1")
	private String reserved1;

	@Column(name = "RESERVED_2")
	private String reserved2;

	@Column(name = "RESERVED_3")
	private String reserved3;

	@Column(name = "RESERVED_4")
	private String reserved4;

	@Column(name = "TIME_ZONE")
	private String timeZone;

	@Column(name = "API_USERNAME")
	private String apiUsername;

	@Column(name = "NODE_ID")
	private String nodeId;

	@Column(name = "CLIENT_IP_ADDRESS")
	private String clientIpAddress;

	@Column(name = "API_CODE")
	private Integer apiCode;

	@Column(name = "MODIFIELD_FLAG")
	private int modifiedFlag;

	@Column(name = "QUOTA_DURATION")
	private Long quotaDuration;

	@Column(name = "QUOTA_COUNTER")
	private String quotaCounter;

	@Column(name = "VALUE")
	private String value;

	@Column(name = "RENEWAL_STATUS")
	private String renewalStatus;

	@Column(name = "RENEWAL_COUNT")
	private BigInteger renewalCount;

	@Column(name = "EVR_TIMESTAMP")
	private Date evrTimeStamp;

	public RenewalEvr() {
		super();
	}

	/*
	 * public Long getRenewalEvrId() { return renewalEvrId; }
	 * 
	 * public void setRenewalEvrId(Long renewalEvrId) { this.renewalEvrId =
	 * renewalEvrId; }
	 */

	public String getOldMac() {
		return oldMac;
	}

	public int getModifiedFlag() {
		return modifiedFlag;
	}

	public void setModifiedFlag(int modifiedFlag) {
		this.modifiedFlag = modifiedFlag;
	}

	public String getRenewalStatus() {
		return renewalStatus;
	}

	public void setRenewalStatus(String renewalStatus) {
		this.renewalStatus = renewalStatus;
	}

	public BigInteger getRenewalCount() {
		return renewalCount;
	}

	public void setRenewalCount(BigInteger renewalCount) {
		this.renewalCount = renewalCount;
	}

	public void setOldMac(String oldMac) {
		this.oldMac = oldMac;
	}

	public String getNewMac() {
		return newMac;
	}

	public void setNewMac(String newMac) {
		this.newMac = newMac;
	}

	public String getAddOnName() {
		return addOnName;
	}

	public void setAddOnName(String addOnName) {
		this.addOnName = addOnName;
	}

	public String getAddOnValue() {
		return addOnValue;
	}

	public void setAddOnValue(String addOnValue) {
		this.addOnValue = addOnValue;
	}

	public String getMacUsername() {
		return macUsername;
	}

	public void setMacUsername(String macUsername) {
		this.macUsername = macUsername;
	}

	public String getServiceOperation() {
		return serviceOperation;
	}

	public void setServiceOperation(String serviceOperation) {
		this.serviceOperation = serviceOperation;
	}

	public Long getIncomingData() {
		return incomingData;
	}

	public void setIncomingData(Long incomingData) {
		this.incomingData = incomingData;
	}

	public Long getOutgoingData() {
		return outgoingData;
	}

	public void setOutgoingData(Long outgoingData) {
		this.outgoingData = outgoingData;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	public Integer getCityID() {
		return cityID;
	}

	public void setCityID(Integer cityID) {
		this.cityID = cityID;
	}

	public Integer getDistrictID() {
		return districtID;
	}

	public void setDistrictID(Integer districtID) {
		this.districtID = districtID;
	}

	public Integer getNeighborhoodID() {
		return neighborhoodID;
	}

	public void setNeighborhoodID(Integer neighborhoodID) {
		this.neighborhoodID = neighborhoodID;
	}

	public Integer getStreetID() {
		return streetID;
	}

	public void setStreetID(Integer streetID) {
		this.streetID = streetID;
	}

	public Integer getCmtsOLTID() {
		return cmtsOLTID;
	}

	public void setCmtsOLTID(Integer cmtsOLTID) {
		this.cmtsOLTID = cmtsOLTID;
	}

	public Long getSecureInternetProfileID() {
		return secureInternetProfileID;
	}

	public void setSecureInternetProfileID(Long secureInternetProfileID) {
		this.secureInternetProfileID = secureInternetProfileID;
	}

	public String getIpv4() {
		return ipv4;
	}

	public void setIpv4(String ipv4) {
		this.ipv4 = ipv4;
	}

	public String getIpv6() {
		return ipv6;
	}

	public void setIpv6(String ipv6) {
		this.ipv6 = ipv6;
	}

	public Long getsEQNO() {
		return sEQNO;
	}

	public void setsEQNO(Long sEQNO) {
		this.sEQNO = sEQNO;
	}

	public String getSubIdentifier() {
		return subIdentifier;
	}

	public void setSubIdentifier(String subIdentifier) {
		this.subIdentifier = subIdentifier;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public Long getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(Long subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCosId() {
		return cosId;
	}

	public void setCosId(String cosId) {
		this.cosId = cosId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getCdrType() {
		return cdrType;
	}

	public void setCdrType(Long cdrType) {
		this.cdrType = cdrType;
	}

	public LocalDateTime getTIMESTAMP() {
		return TIMESTAMP;
	}

	public void setTIMESTAMP(LocalDateTime tIMESTAMP) {
		TIMESTAMP = tIMESTAMP;
	}

	public LocalDateTime getSERVICE_START_TIME() {
		return SERVICE_START_TIME;
	}

	public void setSERVICE_START_TIME(LocalDateTime sERVICE_START_TIME) {
		SERVICE_START_TIME = sERVICE_START_TIME;
	}

	public LocalDateTime getSERVICE_END_TIME() {
		return SERVICE_END_TIME;
	}

	public void setSERVICE_END_TIME(LocalDateTime sERVICE_END_TIME) {
		SERVICE_END_TIME = sERVICE_END_TIME;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getSgsnIp() {
		return sgsnIp;
	}

	public void setSgsnIp(String sgsnIp) {
		this.sgsnIp = sgsnIp;
	}

	public String getSgsnMccMnc() {
		return sgsnMccMnc;
	}

	public void setSgsnMccMnc(String sgsnMccMnc) {
		this.sgsnMccMnc = sgsnMccMnc;
	}

	public String getSgsnTadig() {
		return sgsnTadig;
	}

	public void setSgsnTadig(String sgsnTadig) {
		this.sgsnTadig = sgsnTadig;
	}

	public String getApn() {
		return apn;
	}

	public void setApn(String apn) {
		this.apn = apn;
	}

	public String getLocationAccess() {
		return locationAccess;
	}

	public void setLocationAccess(String locationAccess) {
		this.locationAccess = locationAccess;
	}

	public Long getAccessType() {
		return accessType;
	}

	public void setAccessType(Long accessType) {
		this.accessType = accessType;
	}

	public String getChargingId() {
		return chargingId;
	}

	public void setChargingId(String chargingId) {
		this.chargingId = chargingId;
	}

	public Long getRatingGroup() {
		return ratingGroup;
	}

	public void setRatingGroup(Long ratingGroup) {
		this.ratingGroup = ratingGroup;
	}

	public String getServiceIdentifier() {
		return serviceIdentifier;
	}

	public void setServiceIdentifier(String serviceIdentifier) {
		this.serviceIdentifier = serviceIdentifier;
	}

	

	public String getPackageId() {
		return packageId;
	}

	public void setPackageId(String packageId) {
		this.packageId = packageId;
	}

	public String getBucketId() {
		return bucketId;
	}

	public void setBucketId(String bucketId) {
		this.bucketId = bucketId;
	}

	public Long getServiceReqCount() {
		return serviceReqCount;
	}

	public void setServiceReqCount(Long serviceReqCount) {
		this.serviceReqCount = serviceReqCount;
	}

	public Long getChargeUsed() {
		return chargeUsed;
	}

	public void setChargeUsed(Long chargeUsed) {
		this.chargeUsed = chargeUsed;
	}

	public String getOtherSubIdentifier() {
		return otherSubIdentifier;
	}

	public void setOtherSubIdentifier(String otherSubIdentifier) {
		this.otherSubIdentifier = otherSubIdentifier;
	}

	public Integer getResultCode() {
		return resultCode;
	}

	public void setResultCode(Integer resultCode) {
		this.resultCode = resultCode;
	}

	public String getInReferenceId() {
		return inReferenceId;
	}

	public void setInReferenceId(String inReferenceId) {
		this.inReferenceId = inReferenceId;
	}

	public Long getDownlinkKBytes() {
		return downlinkKBytes;
	}

	public void setDownlinkKBytes(Long downlinkKBytes) {
		this.downlinkKBytes = downlinkKBytes;
	}

	public Long getUplinkKBytes() {
		return uplinkKBytes;
	}

	public void setUplinkKBytes(Long uplinkKBytes) {
		this.uplinkKBytes = uplinkKBytes;
	}

	public String getActualCommUsedRef() {
		return actualCommUsedRef;
	}

	public void setActualCommUsedRef(String actualCommUsedRef) {
		this.actualCommUsedRef = actualCommUsedRef;
	}

	public Long getTotalCommAccounted() {
		return totalCommAccounted;
	}

	public void setTotalCommAccounted(Long totalCommAccounted) {
		this.totalCommAccounted = totalCommAccounted;
	}

	public Long getCommType() {
		return commType;
	}

	public void setCommType(Long commType) {
		this.commType = commType;
	}

	public Long getCharge() {
		return charge;
	}

	public void setCharge(Long charge) {
		this.charge = charge;
	}

	public Long getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(Long totalTax) {
		this.totalTax = totalTax;
	}

	public String getReserved1() {
		return reserved1;
	}

	public void setReserved1(String reserved1) {
		this.reserved1 = reserved1;
	}

	public String getReserved2() {
		return reserved2;
	}

	public void setReserved2(String reserved2) {
		this.reserved2 = reserved2;
	}

	public String getReserved3() {
		return reserved3;
	}

	public void setReserved3(String reserved3) {
		this.reserved3 = reserved3;
	}

	public String getReserved4() {
		return reserved4;
	}

	public void setReserved4(String reserved4) {
		this.reserved4 = reserved4;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getApiUsername() {
		return apiUsername;
	}

	public void setApiUsername(String apiUsername) {
		this.apiUsername = apiUsername;
	}

	public String getNodeId() {
		return nodeId;
	}

	public void setNodeId(String nodeId) {
		this.nodeId = nodeId;
	}

	public String getClientIpAddress() {
		return clientIpAddress;
	}

	public void setClientIpAddress(String clientIpAddress) {
		this.clientIpAddress = clientIpAddress;
	}

	public Integer getApiCode() {
		return apiCode;
	}

	public void setApiCode(Integer apiCode) {
		this.apiCode = apiCode;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public Long getQuotaDuration() {
		return quotaDuration;
	}

	public void setQuotaDuration(Long quotaDuration) {
		this.quotaDuration = quotaDuration;
	}

	public String getQuotaCounter() {
		return quotaCounter;
	}

	public void setQuotaCounter(String quotaCounter) {
		this.quotaCounter = quotaCounter;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public Date getEvrTimeStamp() {
		return evrTimeStamp;
	}

	public void setEvrTimeStamp(Date evrTimeStamp) {
		this.evrTimeStamp = evrTimeStamp;
	}

}
