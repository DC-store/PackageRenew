
package tss.packagerenewal.Model;

import lombok.*;
import org.springframework.lang.Nullable;

import java.time.LocalDateTime;


@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EVRBean {
	@Nullable
	private String OldMac;
	@Nullable
	private String NewMac;
	@Nullable
	private String AddOnName;
	@Nullable
	private String AddOnValue;
	@Nullable
	private String Mac_Username;
	@Nullable
	private String ServiceOperation;
	private Long IncomingData;
	private Long OutgoingData;
	@Nullable
	private String ServiceNo;
	@Nullable
	private Integer CityID;
	@Nullable
	private Integer DistrictID;
	@Nullable
	private Integer NeighborhoodID;
	@Nullable
	private Integer StreetID;
	@Nullable
	private Integer CmtsOLTID;
	private Long SecureInternetProfileID;
	@Nullable
	private String Ipv4;
	@Nullable
	private String Ipv6;
	private Long SEQ_NO;
	@Nullable
	private String SUB_IDENTIFIER;
	@Nullable
	private String ACCOUNT_ID;
	private Long SUBSCRIBER_ID;
	@Nullable
	private String IMEI;
	@Nullable
	private String IMSI;
	private Long SUBSCRIPTION_TYPE;
	@Nullable
	private String CUSTOMER_TYPE;
	@Nullable
	private String COS_ID;
	private Long APPLICATION_ID;
	private Long CDR_TYPE;
	private LocalDateTime TIMESTAMP;
	private LocalDateTime SERVICE_START_TIME;
	private LocalDateTime SERVICE_END_TIME;
	private String SESSION_ID;
	@Nullable
	private String SGSN_IP;
	@Nullable
	private String SGSN_MCC_MNC;
	@Nullable
	private String SGSN_TADIG;
	@Nullable
	private String APN;
	@Nullable
	private String LOCATION_ACCESS;
	private Long ACCESS_TYPE;
	@Nullable
	private String CHARGING_ID;
	private Long RATING_GROUP;
	@Nullable
	private String SERVICE_IDENTIFIER;
	@Nullable
	private Integer PACKAGE_ID;
	@Nullable
	private String BUCKET_ID;
	private Long SERVICE_REQ_COUNT;
	private Long CHARGE_USED;
	@Nullable
	private String OTHER_SUB_IDENTIFIER;
	private Integer RESULT_CODE;
	@Nullable
	private String IN_REFERENCE_ID;
	private Long DOWNLINK_K_BYTES;
	private Long UPLINK_K_BYTES;
	@Nullable
	private String ACTUAL_COMM_USED_REF;
	private Long TOTAL_COMM_ACCOUNTED;
	private Long COMM_TYPE;
	private Long CHARGE;
	private Long TOTAL_TAX;
	@Nullable
	private String RESERVED_1;
	@Nullable
	private String RESERVED_2;
	@Nullable
	private String RESERVED_3;
	@Nullable
	private String RESERVED_4;
	@Nullable
	private String TIME_ZONE;
	private String API_USERNAME;
	private Integer NODE_ID;
	@Nullable
	private String CLIENT_IP_ADDRESS;
	private Integer API_CODE;
	private String TRANSACTION_ID;
	private Long QUOTA_DURATION;
	@Nullable
	private String QUOTA_COUNTER;
	@Nullable
	private String VALUE;

	public String getOldMac() {
		return OldMac;
	}

	public void setOldMac(String oldMac) {
		OldMac = oldMac;
	}

	public String getNewMac() {
		return NewMac;
	}

	public void setNewMac(String newMac) {
		NewMac = newMac;
	}

	public String getAddOnName() {
		return AddOnName;
	}

	public void setAddOnName(String addOnName) {
		AddOnName = addOnName;
	}

	public String getAddOnValue() {
		return AddOnValue;
	}

	public void setAddOnValue(String addOnValue) {
		AddOnValue = addOnValue;
	}

	public String getMac_Username() {
		return Mac_Username;
	}

	public void setMac_Username(String mac_Username) {
		Mac_Username = mac_Username;
	}

	public String getServiceOperation() {
		return ServiceOperation;
	}

	public void setServiceOperation(String serviceOperation) {
		ServiceOperation = serviceOperation;
	}

	public Long getIncomingData() {
		return IncomingData;
	}

	public void setIncomingData(Long incomingData) {
		IncomingData = incomingData;
	}

	public Long getOutgoingData() {
		return OutgoingData;
	}

	public void setOutgoingData(Long outgoingData) {
		OutgoingData = outgoingData;
	}

	public String getServiceNo() {
		return ServiceNo;
	}

	public void setServiceNo(String serviceNo) {
		ServiceNo = serviceNo;
	}

	public Integer getCityID() {
		return CityID;
	}

	public void setCityID(Integer cityID) {
		CityID = cityID;
	}

	public Integer getDistrictID() {
		return DistrictID;
	}

	public void setDistrictID(Integer districtID) {
		DistrictID = districtID;
	}

	public Integer getNeighborhoodID() {
		return NeighborhoodID;
	}

	public void setNeighborhoodID(Integer neighborhoodID) {
		NeighborhoodID = neighborhoodID;
	}

	public Integer getStreetID() {
		return StreetID;
	}

	public void setStreetID(Integer streetID) {
		StreetID = streetID;
	}

	public Integer getCmtsOLTID() {
		return CmtsOLTID;
	}

	public void setCmtsOLTID(Integer cmtsOLTID) {
		CmtsOLTID = cmtsOLTID;
	}

	public Long getSecureInternetProfileID() {
		return SecureInternetProfileID;
	}

	public void setSecureInternetProfileID(Long secureInternetProfileID) {
		SecureInternetProfileID = secureInternetProfileID;
	}

	public String getIpv4() {
		return Ipv4;
	}

	public void setIpv4(String ipv4) {
		Ipv4 = ipv4;
	}

	public String getIpv6() {
		return Ipv6;
	}

	public void setIpv6(String ipv6) {
		Ipv6 = ipv6;
	}

	public Long getSEQ_NO() {
		return SEQ_NO;
	}

	public void setSEQ_NO(Long sEQ_NO) {
		SEQ_NO = sEQ_NO;
	}

	public String getSUB_IDENTIFIER() {
		return SUB_IDENTIFIER;
	}

	public void setSUB_IDENTIFIER(String sUB_IDENTIFIER) {
		SUB_IDENTIFIER = sUB_IDENTIFIER;
	}

	public String getACCOUNT_ID() {
		return ACCOUNT_ID;
	}

	public void setACCOUNT_ID(String aCCOUNT_ID) {
		ACCOUNT_ID = aCCOUNT_ID;
	}

	public Long getSUBSCRIBER_ID() {
		return SUBSCRIBER_ID;
	}

	public void setSUBSCRIBER_ID(Long sUBSCRIBER_ID) {
		SUBSCRIBER_ID = sUBSCRIBER_ID;
	}

	public String getIMEI() {
		return IMEI;
	}

	public void setIMEI(String iMEI) {
		IMEI = iMEI;
	}

	public String getIMSI() {
		return IMSI;
	}

	public void setIMSI(String iMSI) {
		IMSI = iMSI;
	}

	public Long getSUBSCRIPTION_TYPE() {
		return SUBSCRIPTION_TYPE;
	}

	public void setSUBSCRIPTION_TYPE(Long sUBSCRIPTION_TYPE) {
		SUBSCRIPTION_TYPE = sUBSCRIPTION_TYPE;
	}

	public String getCUSTOMER_TYPE() {
		return CUSTOMER_TYPE;
	}

	public void setCUSTOMER_TYPE(String cUSTOMER_TYPE) {
		CUSTOMER_TYPE = cUSTOMER_TYPE;
	}

	public String getCOS_ID() {
		return COS_ID;
	}

	public void setCOS_ID(String cOS_ID) {
		COS_ID = cOS_ID;
	}

	public Long getAPPLICATION_ID() {
		return APPLICATION_ID;
	}

	public void setAPPLICATION_ID(Long aPPLICATION_ID) {
		APPLICATION_ID = aPPLICATION_ID;
	}

	public Long getCDR_TYPE() {
		return CDR_TYPE;
	}

	public void setCDR_TYPE(Long cDR_TYPE) {
		CDR_TYPE = cDR_TYPE;
	}

	public LocalDateTime getTIMESTAMP() {
		return TIMESTAMP;
	}

	public void setTIMESTAMP(LocalDateTime tIMESTAMP) {
		TIMESTAMP = tIMESTAMP;
	}

	public LocalDateTime getSERVICE_START_TIME() {
		return SERVICE_START_TIME;
	}

	public void setSERVICE_START_TIME(LocalDateTime sERVICE_START_TIME) {
		SERVICE_START_TIME = sERVICE_START_TIME;
	}

	public LocalDateTime getSERVICE_END_TIME() {
		return SERVICE_END_TIME;
	}

	public void setSERVICE_END_TIME(LocalDateTime sERVICE_END_TIME) {
		SERVICE_END_TIME = sERVICE_END_TIME;
	}

	public String getSESSION_ID() {
		return SESSION_ID;
	}

	public void setSESSION_ID(String sESSION_ID) {
		SESSION_ID = sESSION_ID;
	}

	public String getSGSN_IP() {
		return SGSN_IP;
	}

	public void setSGSN_IP(String sGSN_IP) {
		SGSN_IP = sGSN_IP;
	}

	public String getSGSN_MCC_MNC() {
		return SGSN_MCC_MNC;
	}

	public void setSGSN_MCC_MNC(String sGSN_MCC_MNC) {
		SGSN_MCC_MNC = sGSN_MCC_MNC;
	}

	public String getSGSN_TADIG() {
		return SGSN_TADIG;
	}

	public void setSGSN_TADIG(String sGSN_TADIG) {
		SGSN_TADIG = sGSN_TADIG;
	}

	public String getAPN() {
		return APN;
	}

	public void setAPN(String aPN) {
		APN = aPN;
	}

	public String getLOCATION_ACCESS() {
		return LOCATION_ACCESS;
	}

	public void setLOCATION_ACCESS(String lOCATION_ACCESS) {
		LOCATION_ACCESS = lOCATION_ACCESS;
	}

	public Long getACCESS_TYPE() {
		return ACCESS_TYPE;
	}

	public void setACCESS_TYPE(Long aCCESS_TYPE) {
		ACCESS_TYPE = aCCESS_TYPE;
	}

	public String getCHARGING_ID() {
		return CHARGING_ID;
	}

	public void setCHARGING_ID(String cHARGING_ID) {
		CHARGING_ID = cHARGING_ID;
	}

	public Long getRATING_GROUP() {
		return RATING_GROUP;
	}

	public void setRATING_GROUP(Long rATING_GROUP) {
		RATING_GROUP = rATING_GROUP;
	}

	public String getSERVICE_IDENTIFIER() {
		return SERVICE_IDENTIFIER;
	}

	public void setSERVICE_IDENTIFIER(String sERVICE_IDENTIFIER) {
		SERVICE_IDENTIFIER = sERVICE_IDENTIFIER;
	}

	public Integer getPACKAGE_ID() {
		return PACKAGE_ID;
	}

	public void setPACKAGE_ID(Integer pACKAGE_ID) {
		PACKAGE_ID = pACKAGE_ID;
	}

	public String getBUCKET_ID() {
		return BUCKET_ID;
	}

	public void setBUCKET_ID(String bUCKET_ID) {
		BUCKET_ID = bUCKET_ID;
	}

	public Long getSERVICE_REQ_COUNT() {
		return SERVICE_REQ_COUNT;
	}

	public void setSERVICE_REQ_COUNT(Long sERVICE_REQ_COUNT) {
		SERVICE_REQ_COUNT = sERVICE_REQ_COUNT;
	}

	public Long getCHARGE_USED() {
		return CHARGE_USED;
	}

	public void setCHARGE_USED(Long cHARGE_USED) {
		CHARGE_USED = cHARGE_USED;
	}

	public String getOTHER_SUB_IDENTIFIER() {
		return OTHER_SUB_IDENTIFIER;
	}

	public void setOTHER_SUB_IDENTIFIER(String oTHER_SUB_IDENTIFIER) {
		OTHER_SUB_IDENTIFIER = oTHER_SUB_IDENTIFIER;
	}

	public Integer getRESULT_CODE() {
		return RESULT_CODE;
	}

	public void setRESULT_CODE(Integer rESULT_CODE) {
		RESULT_CODE = rESULT_CODE;
	}

	public String getIN_REFERENCE_ID() {
		return IN_REFERENCE_ID;
	}

	public void setIN_REFERENCE_ID(String iN_REFERENCE_ID) {
		IN_REFERENCE_ID = iN_REFERENCE_ID;
	}

	public Long getDOWNLINK_K_BYTES() {
		return DOWNLINK_K_BYTES;
	}

	public void setDOWNLINK_K_BYTES(Long dOWNLINK_K_BYTES) {
		DOWNLINK_K_BYTES = dOWNLINK_K_BYTES;
	}

	public Long getUPLINK_K_BYTES() {
		return UPLINK_K_BYTES;
	}

	public void setUPLINK_K_BYTES(Long uPLINK_K_BYTES) {
		UPLINK_K_BYTES = uPLINK_K_BYTES;
	}

	public String getACTUAL_COMM_USED_REF() {
		return ACTUAL_COMM_USED_REF;
	}

	public void setACTUAL_COMM_USED_REF(String aCTUAL_COMM_USED_REF) {
		ACTUAL_COMM_USED_REF = aCTUAL_COMM_USED_REF;
	}

	public Long getTOTAL_COMM_ACCOUNTED() {
		return TOTAL_COMM_ACCOUNTED;
	}

	public void setTOTAL_COMM_ACCOUNTED(Long tOTAL_COMM_ACCOUNTED) {
		TOTAL_COMM_ACCOUNTED = tOTAL_COMM_ACCOUNTED;
	}

	public Long getCOMM_TYPE() {
		return COMM_TYPE;
	}

	public void setCOMM_TYPE(Long cOMM_TYPE) {
		COMM_TYPE = cOMM_TYPE;
	}

	public Long getCHARGE() {
		return CHARGE;
	}

	public void setCHARGE(Long cHARGE) {
		CHARGE = cHARGE;
	}

	public Long getTOTAL_TAX() {
		return TOTAL_TAX;
	}

	public void setTOTAL_TAX(Long tOTAL_TAX) {
		TOTAL_TAX = tOTAL_TAX;
	}

	public String getRESERVED_1() {
		return RESERVED_1;
	}

	public void setRESERVED_1(String rESERVED_1) {
		RESERVED_1 = rESERVED_1;
	}

	public String getRESERVED_2() {
		return RESERVED_2;
	}

	public void setRESERVED_2(String rESERVED_2) {
		RESERVED_2 = rESERVED_2;
	}

	public String getRESERVED_3() {
		return RESERVED_3;
	}

	public void setRESERVED_3(String rESERVED_3) {
		RESERVED_3 = rESERVED_3;
	}

	public String getRESERVED_4() {
		return RESERVED_4;
	}

	public void setRESERVED_4(String rESERVED_4) {
		RESERVED_4 = rESERVED_4;
	}

	public String getTIME_ZONE() {
		return TIME_ZONE;
	}

	public void setTIME_ZONE(String tIME_ZONE) {
		TIME_ZONE = tIME_ZONE;
	}

	public String getAPI_USERNAME() {
		return API_USERNAME;
	}

	public void setAPI_USERNAME(String aPI_USERNAME) {
		API_USERNAME = aPI_USERNAME;
	}

	public Integer getNODE_ID() {
		return NODE_ID;
	}

	public void setNODE_ID(Integer nODE_ID) {
		NODE_ID = nODE_ID;
	}

	public String getCLIENT_IP_ADDRESS() {
		return CLIENT_IP_ADDRESS;
	}

	public void setCLIENT_IP_ADDRESS(String cLIENT_IP_ADDRESS) {
		CLIENT_IP_ADDRESS = cLIENT_IP_ADDRESS;
	}

	public Integer getAPI_CODE() {
		return API_CODE;
	}

	public void setAPI_CODE(Integer aPI_CODE) {
		API_CODE = aPI_CODE;
	}

	public String getTRANSACTION_ID() {
		return TRANSACTION_ID;
	}

	public void setTRANSACTION_ID(String tRANSACTION_ID) {
		TRANSACTION_ID = tRANSACTION_ID;
	}

	public Long getQUOTA_DURATION() {
		return QUOTA_DURATION;
	}

	public void setQUOTA_DURATION(Long qUOTA_DURATION) {
		QUOTA_DURATION = qUOTA_DURATION;
	}

	public String getQUOTA_COUNTER() {
		return QUOTA_COUNTER;
	}

	public void setQUOTA_COUNTER(String qUOTA_COUNTER) {
		QUOTA_COUNTER = qUOTA_COUNTER;
	}

	public String getVALUE() {
		return VALUE;
	}

	public void setVALUE(String vALUE) {
		VALUE = vALUE;
	}

	@Override
	public String toString() {
		return "EVRBean [OldMac=" + OldMac + ", NewMac=" + NewMac + ", AddOnName=" + AddOnName + ", AddOnValue="
				+ AddOnValue + ", Mac_Username=" + Mac_Username + ", ServiceOperation=" + ServiceOperation
				+ ", IncomingData=" + IncomingData + ", OutgoingData=" + OutgoingData + ", ServiceNo=" + ServiceNo
				+ ", CityID=" + CityID + ", DistrictID=" + DistrictID + ", NeighborhoodID=" + NeighborhoodID
				+ ", StreetID=" + StreetID + ", CmtsOLTID=" + CmtsOLTID + ", SecureInternetProfileID="
				+ SecureInternetProfileID + ", Ipv4=" + Ipv4 + ", Ipv6=" + Ipv6 + ", SEQ_NO=" + SEQ_NO
				+ ", SUB_IDENTIFIER=" + SUB_IDENTIFIER + ", ACCOUNT_ID=" + ACCOUNT_ID + ", SUBSCRIBER_ID="
				+ SUBSCRIBER_ID + ", IMEI=" + IMEI + ", IMSI=" + IMSI + ", SUBSCRIPTION_TYPE=" + SUBSCRIPTION_TYPE
				+ ", CUSTOMER_TYPE=" + CUSTOMER_TYPE + ", COS_ID=" + COS_ID + ", APPLICATION_ID=" + APPLICATION_ID
				+ ", CDR_TYPE=" + CDR_TYPE + ", TIMESTAMP=" + TIMESTAMP + ", SERVICE_START_TIME=" + SERVICE_START_TIME
				+ ", SERVICE_END_TIME=" + SERVICE_END_TIME + ", SESSION_ID=" + SESSION_ID + ", SGSN_IP=" + SGSN_IP
				+ ", SGSN_MCC_MNC=" + SGSN_MCC_MNC + ", SGSN_TADIG=" + SGSN_TADIG + ", APN=" + APN
				+ ", LOCATION_ACCESS=" + LOCATION_ACCESS + ", ACCESS_TYPE=" + ACCESS_TYPE + ", CHARGING_ID="
				+ CHARGING_ID + ", RATING_GROUP=" + RATING_GROUP + ", SERVICE_IDENTIFIER=" + SERVICE_IDENTIFIER
				+ ", PACKAGE_ID=" + PACKAGE_ID + ", BUCKET_ID=" + BUCKET_ID + ", SERVICE_REQ_COUNT=" + SERVICE_REQ_COUNT
				+ ", CHARGE_USED=" + CHARGE_USED + ", OTHER_SUB_IDENTIFIER=" + OTHER_SUB_IDENTIFIER + ", RESULT_CODE="
				+ RESULT_CODE + ", IN_REFERENCE_ID=" + IN_REFERENCE_ID + ", DOWNLINK_K_BYTES=" + DOWNLINK_K_BYTES
				+ ", UPLINK_K_BYTES=" + UPLINK_K_BYTES + ", ACTUAL_COMM_USED_REF=" + ACTUAL_COMM_USED_REF
				+ ", TOTAL_COMM_ACCOUNTED=" + TOTAL_COMM_ACCOUNTED + ", COMM_TYPE=" + COMM_TYPE + ", CHARGE=" + CHARGE
				+ ", TOTAL_TAX=" + TOTAL_TAX + ", RESERVED_1=" + RESERVED_1 + ", RESERVED_2=" + RESERVED_2
				+ ", RESERVED_3=" + RESERVED_3 + ", RESERVED_4=" + RESERVED_4 + ", TIME_ZONE=" + TIME_ZONE
				+ ", API_USERNAME=" + API_USERNAME + ", NODE_ID=" + NODE_ID + ", CLIENT_IP_ADDRESS=" + CLIENT_IP_ADDRESS
				+ ", API_CODE=" + API_CODE + ", TRANSACTION_ID=" + TRANSACTION_ID + ", QUOTA_DURATION=" + QUOTA_DURATION
				+ ", QUOTA_COUNTER=" + QUOTA_COUNTER + ", VALUE=" + VALUE + "]";
	}
}