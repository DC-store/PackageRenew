package tss.packagerenewal.Entity;

import java.math.BigInteger;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "wdbs_subscriber_account_3")
public class WdbsSubscriberAccount3 {
	
	@Id
	@Column(name = "ACCOUNT", nullable = false)
	private Long account;

	@Column(name = "ACCUMULATED_ACCOUNT", nullable = false)
	private Long accumulatedAccount;

	@Column(name = "CHARGE_RULE_ID", nullable = false)
	private Long chargeRuleId;

	@Column(name = "CUST_BUCKET", nullable = false)
	private Long custBucket;

	@Column(name = "CUST_QOS_ID", nullable = false)
	private Long custQosId;

	@Column(name = "CUST_QOS_WEIGHT", nullable = false)
	private Long custQuoWeight;

	@Column(name = "CUST_VALIDITY", nullable = false)
	private Long custValidity;

	@Column(name = "DEBIT_REDIRECT", nullable = false)
	private Integer debitRedirect;

	@Column(name = "DIFFERENCE_USAGE", nullable = false)
	private Long differenceUsage;

	@Column(name = "FROM_DATE", nullable = false)
	private Date fromDate;

	@Column(name = "GGSN_SESSION_ID", nullable = false)
	private String ggsnSessionId;

	@Column(name = "IMEI", nullable = false)
	private String imei;

	@Column(name = "LAST_MODIFIED_TIME", nullable = false)
	private Date lastModifiedTime;

	@Column(name = "LAST_SESSION_TIME", nullable = false)
	private Date lastSessionTime;

	@Column(name = "MSISDN", nullable = false)
	private Long msisdn;

	@Column(name = "PACKAGE_ID", nullable = false)
	private BigInteger packageid;

	@Column(name = "PREV_ACCOUNT", nullable = false)
	private String prevAccount;

	@Column(name = "PREV_TO_DATE", nullable = false)
	private Date prevToDate;

	@Column(name = "PRIORITY", nullable = false)
	private Integer priority;

	@Column(name = "SLIDING_USAGE", nullable = false)
	private String slidingUsage;

	@Column(name = "STATUS", nullable = false)
	private Integer status;

	@Column(name = "SUBSCRIBER_ID", nullable = false)
	private Long subscriberId;

	@Column(name = "THRESHOLD", nullable = false)
	private Long threshold;

	@Column(name = "THRESHOLD_DET", nullable = false)
	private String thresholdDet;

	@Column(name = "TO_DATE", nullable = false)
	private Date toDate;

	@Column(name = "USAGE", nullable = false)
	private Long usage;

	@Column(name = "USAGE_UNITS", nullable = false)
	private Integer usageUnits;

	public Long getAccount() {
		return account;
	}

	public void setAccount(Long account) {
		this.account = account;
	}

	public Long getAccumulatedAccount() {
		return accumulatedAccount;
	}

	public void setAccumulatedAccount(Long accumulatedAccount) {
		this.accumulatedAccount = accumulatedAccount;
	}

	public Long getChargeRuleId() {
		return chargeRuleId;
	}

	public void setChargeRuleId(Long chargeRuleId) {
		this.chargeRuleId = chargeRuleId;
	}

	public Long getCustBucket() {
		return custBucket;
	}

	public void setCustBucket(Long custBucket) {
		this.custBucket = custBucket;
	}

	public Long getCustQosId() {
		return custQosId;
	}

	public void setCustQosId(Long custQosId) {
		this.custQosId = custQosId;
	}

	public Long getCustQuoWeight() {
		return custQuoWeight;
	}

	public void setCustQuoWeight(Long custQuoWeight) {
		this.custQuoWeight = custQuoWeight;
	}

	public Long getCustValidity() {
		return custValidity;
	}

	public void setCustValidity(Long custValidity) {
		this.custValidity = custValidity;
	}

	public Integer getDebitRedirect() {
		return debitRedirect;
	}

	public void setDebitRedirect(Integer debitRedirect) {
		this.debitRedirect = debitRedirect;
	}

	public Long getDifferenceUsage() {
		return differenceUsage;
	}

	public void setDifferenceUsage(Long differenceUsage) {
		this.differenceUsage = differenceUsage;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public String getGgsnSessionId() {
		return ggsnSessionId;
	}

	public void setGgsnSessionId(String ggsnSessionId) {
		this.ggsnSessionId = ggsnSessionId;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public Date getLastModifiedTime() {
		return lastModifiedTime;
	}

	public void setLastModifiedTime(Date lastModifiedTime) {
		this.lastModifiedTime = lastModifiedTime;
	}

	public Date getLastSessionTime() {
		return lastSessionTime;
	}

	public void setLastSessionTime(Date lastSessionTime) {
		this.lastSessionTime = lastSessionTime;
	}

	public Long getMsisdn() {
		return msisdn;
	}

	public void setMsisdn(Long msisdn) {
		this.msisdn = msisdn;
	}

	public BigInteger getPackageid() {
		return packageid;
	}

	public void setPackageid(BigInteger packageid) {
		this.packageid = packageid;
	}

	public String getPrevAccount() {
		return prevAccount;
	}

	public void setPrevAccount(String prevAccount) {
		this.prevAccount = prevAccount;
	}

	public Date getPrevToDate() {
		return prevToDate;
	}

	public void setPrevToDate(Date prevToDate) {
		this.prevToDate = prevToDate;
	}

	public Integer getPriority() {
		return priority;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public String getSlidingUsage() {
		return slidingUsage;
	}

	public void setSlidingUsage(String slidingUsage) {
		this.slidingUsage = slidingUsage;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public Long getThreshold() {
		return threshold;
	}

	public void setThreshold(Long threshold) {
		this.threshold = threshold;
	}

	public String getThresholdDet() {
		return thresholdDet;
	}

	public void setThresholdDet(String thresholdDet) {
		this.thresholdDet = thresholdDet;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

	public Long getUsage() {
		return usage;
	}

	public void setUsage(Long usage) {
		this.usage = usage;
	}

	public Integer getUsageUnits() {
		return usageUnits;
	}

	public void setUsageUnits(Integer usageUnits) {
		this.usageUnits = usageUnits;
	}

	@Override
	public String toString() {
		return "WdbsSubscriberAccount3 [account=" + account + ", accumulatedAccount=" + accumulatedAccount
				+ ", chargeRuleId=" + chargeRuleId + ", custBucket=" + custBucket + ", custQosId=" + custQosId
				+ ", custQuoWeight=" + custQuoWeight + ", custValidity=" + custValidity + ", debitRedirect="
				+ debitRedirect + ", differenceUsage=" + differenceUsage + ", fromDate=" + fromDate + ", ggsnSessionId="
				+ ggsnSessionId + ", imei=" + imei + ", lastModifiedTime=" + lastModifiedTime + ", lastSessionTime="
				+ lastSessionTime + ", msisdn=" + msisdn + ", packageid=" + packageid + ", prevAccount=" + prevAccount
				+ ", prevToDate=" + prevToDate + ", priority=" + priority + ", slidingUsage=" + slidingUsage
				+ ", status=" + status + ", subscriberId=" + subscriberId + ", threshold=" + threshold
				+ ", thresholdDet=" + thresholdDet + ", toDate=" + toDate + ", usage=" + usage + ", usageUnits="
				+ usageUnits + "]";
	}

	public WdbsSubscriberAccount3(Long account, Long accumulatedAccount, Long chargeRuleId, Long custBucket,
			Long custQosId, Long custQuoWeight, Long custValidity, Integer debitRedirect, Long differenceUsage,
			Date fromDate, String ggsnSessionId, String imei, Date lastModifiedTime, Date lastSessionTime, Long msisdn,
			BigInteger packageid, String prevAccount, Date prevToDate, Integer priority, String slidingUsage,
			Integer status, Long subscriberId, Long threshold, String thresholdDet, Date toDate, Long usage,
			Integer usageUnits) {
		super();
		this.account = account;
		this.accumulatedAccount = accumulatedAccount;
		this.chargeRuleId = chargeRuleId;
		this.custBucket = custBucket;
		this.custQosId = custQosId;
		this.custQuoWeight = custQuoWeight;
		this.custValidity = custValidity;
		this.debitRedirect = debitRedirect;
		this.differenceUsage = differenceUsage;
		this.fromDate = fromDate;
		this.ggsnSessionId = ggsnSessionId;
		this.imei = imei;
		this.lastModifiedTime = lastModifiedTime;
		this.lastSessionTime = lastSessionTime;
		this.msisdn = msisdn;
		this.packageid = packageid;
		this.prevAccount = prevAccount;
		this.prevToDate = prevToDate;
		this.priority = priority;
		this.slidingUsage = slidingUsage;
		this.status = status;
		this.subscriberId = subscriberId;
		this.threshold = threshold;
		this.thresholdDet = thresholdDet;
		this.toDate = toDate;
		this.usage = usage;
		this.usageUnits = usageUnits;
	}

	public WdbsSubscriberAccount3() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
	

}
