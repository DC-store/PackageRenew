package tss.packagerenewal.Entity;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "wdbs_subscriber_profile")
public class WdbsSubscriberProfileDAO {
	@Id
	@Column(name = "SUB_DET_ID" )
	private BigInteger subDetId;

	@Column(name = "SUBSCRIBER_ID")
	private Long subscriberId;
	
	@Column(name = "PACKAGE_ID")
	private BigInteger packageId;

	public BigInteger getSubDetId() {
		return subDetId;
	}

	public void setSubDetId(BigInteger subDetId) {
		this.subDetId = subDetId;
	}

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public BigInteger getPackageId() {
		return packageId;
	}

	public void setPackageId(BigInteger packageId) {
		this.packageId = packageId;
	}

	@Override
	public String toString() {
		return "WdbsSubscriberProfileDAO [subDetId=" + subDetId + ", subscriberId=" + subscriberId + ", packageId="
				+ packageId + "]";
	}

	public WdbsSubscriberProfileDAO(BigInteger subDetId, Long subscriberId, BigInteger packageId) {
		super();
		this.subDetId = subDetId;
		this.subscriberId = subscriberId;
		this.packageId = packageId;
	}

	public WdbsSubscriberProfileDAO() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
