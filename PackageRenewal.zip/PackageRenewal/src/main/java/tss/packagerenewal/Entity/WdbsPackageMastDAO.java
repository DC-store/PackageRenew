package tss.packagerenewal.Entity;

import java.math.BigInteger;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "wdbs_package_mast")
public class WdbsPackageMastDAO {
	
	@Id
	@Column(name = "PACKAGE_ID" )
	private BigInteger packageId;

	@Column(name = "PACKAGE_CLASSIFY")
	private int packageClassify;

	public BigInteger getPackageId() {
		return packageId;
	}

	public void setPackageId(BigInteger packageId) {
		this.packageId = packageId;
	}

	public int getPackageClassify() {
		return packageClassify;
	}

	public void setPackageClassify(int packageClassify) {
		this.packageClassify = packageClassify;
	}

	@Override
	public String toString() {
		return "WdbsPackageMastDAO [packageId=" + packageId + ", packageClassify=" + packageClassify + "]";
	}

	public WdbsPackageMastDAO(BigInteger packageId, int packageClassify) {
		super();
		this.packageId = packageId;
		this.packageClassify = packageClassify;
	}

	public WdbsPackageMastDAO() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
