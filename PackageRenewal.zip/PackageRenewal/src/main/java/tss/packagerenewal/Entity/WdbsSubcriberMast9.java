package tss.packagerenewal.Entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "wdbs_subscriber_mast_9")
public class WdbsSubcriberMast9 {


	@Column(name = "SUBSCRIBER_ID" ,nullable = false)
	private Long subscriberId;

	@Id
	@Column(name = "MSISDN" , nullable = false)
	private Long id;

	@Column(name = "SUBSCRIBER_TYPE", nullable = true)
	private Long subscriberType;

	@Column(name = "DATE_TIME", nullable = true)
	private Date dateTime;

	@Column(name = "STATUS", nullable = true)
	private int status;

	@Column(name = "IMSI", nullable = true)
	private String imsi;

	@Column(name = "DOB", nullable = true)
	private Date dob;

	@Column(name = "OPERATOR_ID", nullable = true)
	private String operatorId;

	public LocalDateTime getCreditDate() {
		return creditDate;
	}

	public void setCreditDate(LocalDateTime creditDate) {
		this.creditDate = creditDate;
	}

	@Column(name = "LANGUAGE", nullable = true)
	private String language;

	@Column(name = "DEFAULT_PACKAGE", nullable = true)
	private Long defaultPackage;

	@Column(name = "CREDITS", nullable = true)
	private Integer   credits;

	@Column(name = "CREDIT_DATE", nullable = true)
	private LocalDateTime creditDate;

	@Column(name = "C_TYPE", nullable = true)
	private String cType;

	@Column(name = "IN_COS_ID", nullable = true)
	private String inCosId;

	@Column(name = "REGION_ID", nullable = true)
	private Long regionId;

	@Column(name = "PROVINCE_ID", nullable = true)
	private Long provinceId;

	@Column(name = "IN_CREATE_DATE", nullable = true)
	private Date inCreateDate;

	@Column(name = "EMAIL", nullable = true)
	private String email;

	@Column(name = "USER_NAME", nullable = true)
	private String userName;

	@Column(name = "PASSWORD", nullable = true)
	private String password;

	@Column(name = "PROV_TYPE", nullable = true)
	private String provType;

	@Column(name = "SUBS_ACCOUNT_NO", nullable = true)
	private String subsAccountNo;

	@Column(name = "ALTERNATE_NUM", nullable = true)
	private String alternateNo;

	@Column(name = "SUBSCRIBERIP", nullable = true)
	private String subscriberIp;

	@Column(name = "SUBSCRIBERGWIP", nullable = true)
	private String subscriberWip;

	@Column(name = "TOS", nullable = true)
	private String tos;

	@Column(name = "MARKETINGCATEGORY", nullable = true)
	private Integer marketingcategory;

	@Column(name = "SERVICE_NO", nullable = true)
	private String serviceNo;

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getSubscriberType() {
		return subscriberType;
	}

	public void setSubscriberType(Long subscriberType) {
		this.subscriberType = subscriberType;
	}

	public Date getDateTime() {
		return dateTime;
	}

	public void setDateTime(Date dateTime) {
		this.dateTime = dateTime;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getOperatorId() {
		return operatorId;
	}

	public void setOperatorId(String operatorId) {
		this.operatorId = operatorId;
	}

	public String getLanguage() {
		return language;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public Long getDefaultPackage() {
		return defaultPackage;
	}

	public void setDefaultPackage(Long defaultPackage) {
		this.defaultPackage = defaultPackage;
	}

	public Integer getCredits() {
		return credits;
	}

	public void setCredits(Integer credits) {
		this.credits = credits;
	}

	public String getcType() {
		return cType;
	}

	public void setcType(String cType) {
		this.cType = cType;
	}

	public String getInCosId() {
		return inCosId;
	}

	public void setInCosId(String inCosId) {
		this.inCosId = inCosId;
	}

	public Long getRegionId() {
		return regionId;
	}

	public void setRegionId(Long regionId) {
		this.regionId = regionId;
	}

	public Long getProvinceId() {
		return provinceId;
	}

	public void setProvinceId(Long provinceId) {
		this.provinceId = provinceId;
	}

	public Date getInCreateDate() {
		return inCreateDate;
	}

	public void setInCreateDate(Date inCreateDate) {
		this.inCreateDate = inCreateDate;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getProvType() {
		return provType;
	}

	public void setProvType(String provType) {
		this.provType = provType;
	}

	public String getSubsAccountNo() {
		return subsAccountNo;
	}

	public void setSubsAccountNo(String subsAccountNo) {
		this.subsAccountNo = subsAccountNo;
	}

	public String getAlternateNo() {
		return alternateNo;
	}

	public void setAlternateNo(String alternateNo) {
		this.alternateNo = alternateNo;
	}

	public String getSubscriberIp() {
		return subscriberIp;
	}

	public void setSubscriberIp(String subscriberIp) {
		this.subscriberIp = subscriberIp;
	}

	public String getSubscriberWip() {
		return subscriberWip;
	}

	public void setSubscriberWip(String subscriberWip) {
		this.subscriberWip = subscriberWip;
	}

	public String getTos() {
		return tos;
	}

	public void setTos(String tos) {
		this.tos = tos;
	}

	public Integer getMarketingcategory() {
		return marketingcategory;
	}

	public void setMarketingcategory(Integer marketingcategory) {
		this.marketingcategory = marketingcategory;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	@Override
	public String toString() {
		return "WdbsSubcriberMast9 [subscriberId=" + subscriberId + ", id=" + id + ", subscriberType=" + subscriberType
				+ ", dateTime=" + dateTime + ", status=" + status + ", imsi=" + imsi + ", dob=" + dob + ", operatorId="
				+ operatorId + ", language=" + language + ", defaultPackage=" + defaultPackage + ", credits=" + credits
				+ ", creditDate=" + creditDate + ", cType=" + cType + ", inCosId=" + inCosId + ", regionId=" + regionId
				+ ", provinceId=" + provinceId + ", inCreateDate=" + inCreateDate + ", email=" + email + ", userName="
				+ userName + ", password=" + password + ", provType=" + provType + ", subsAccountNo=" + subsAccountNo
				+ ", alternateNo=" + alternateNo + ", subscriberIp=" + subscriberIp + ", subscriberWip=" + subscriberWip
				+ ", tos=" + tos + ", marketingcategory=" + marketingcategory + ", serviceNo=" + serviceNo + "]";
	}

	public WdbsSubcriberMast9(Long subscriberId, Long id, Long subscriberType, Date dateTime, int status, String imsi,
			Date dob, String operatorId, String language, Long defaultPackage, Integer credits,
			LocalDateTime creditDate, String cType, String inCosId, Long regionId, Long provinceId, Date inCreateDate,
			String email, String userName, String password, String provType, String subsAccountNo, String alternateNo,
			String subscriberIp, String subscriberWip, String tos, Integer marketingcategory, String serviceNo) {
		super();
		this.subscriberId = subscriberId;
		this.id = id;
		this.subscriberType = subscriberType;
		this.dateTime = dateTime;
		this.status = status;
		this.imsi = imsi;
		this.dob = dob;
		this.operatorId = operatorId;
		this.language = language;
		this.defaultPackage = defaultPackage;
		this.credits = credits;
		this.creditDate = creditDate;
		this.cType = cType;
		this.inCosId = inCosId;
		this.regionId = regionId;
		this.provinceId = provinceId;
		this.inCreateDate = inCreateDate;
		this.email = email;
		this.userName = userName;
		this.password = password;
		this.provType = provType;
		this.subsAccountNo = subsAccountNo;
		this.alternateNo = alternateNo;
		this.subscriberIp = subscriberIp;
		this.subscriberWip = subscriberWip;
		this.tos = tos;
		this.marketingcategory = marketingcategory;
		this.serviceNo = serviceNo;
	}

	public WdbsSubcriberMast9() {
		super();
		// TODO Auto-generated constructor stub
	}

	
	

}
