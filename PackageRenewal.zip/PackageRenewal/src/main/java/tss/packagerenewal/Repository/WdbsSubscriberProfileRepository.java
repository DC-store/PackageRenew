package tss.packagerenewal.Repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tss.packagerenewal.Entity.WdbsSubscriberProfileDAO;

import javax.transaction.Transactional;

@Repository
public interface WdbsSubscriberProfileRepository extends JpaRepository<WdbsSubscriberProfileDAO, BigInteger> {

	
	@Query(value="select PACKAGE_ID from wdbs_subscriber_profile where SUBSCRIBER_ID= :subscriberVerify ;" ,nativeQuery = true)
	public List<BigInteger> fetchingPackageId(@Param("subscriberVerify")  String subscriberVerify);

	
	
	@Query(value="select PACKAGE_ID from wdbs_subscriber_profile where SUBSCRIBER_ID= :subscriberVerify ;" ,nativeQuery = true)
	public List<BigInteger> packageIdFetching(@Param("subscriberVerify") BigInteger subscriberVerify);

	@Transactional
	@Modifying
	@Query(value = "DELETE FROM wdbs_subscriber_profile WHERE SUBSCRIBER_ID = :subscriberIdResult",nativeQuery = true)
	public void deletetheId(@Param("subscriberIdResult") Long subscriberIdResult);
	
}
