package tss.packagerenewal.Repository;

import java.util.List;
import java.util.Map;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import tss.packagerenewal.Entity.WdbsSubscriberAccount0;



@Repository
public interface WdbsSubscriberAccount0Repo extends JpaRepository<WdbsSubscriberAccount0, Long> {

	
	
	
	
	
	@Query(value ="SELECT SUBSCRIBER_ID FROM wdbs_subscriber_account_0 WHERE SUBSCRIBER_ID = :subscriberId  ;" , nativeQuery = true)
	 public List<Long> findSubscriberId(@Param("subscriberId") Long subscriberId);

	
	
	


	@Query(value = "SELECT CHARGE_RULE_ID FROM wdbs_subscriber_account_0 WHERE SUBSCRIBER_ID = :subscriberId",nativeQuery = true)
	public List<Long> getChargeRule(@Param("subscriberId") Long subscriberId);




	
	
	



	@Transactional
	@Modifying 
	@Query(value = "DELETE FROM wdbs_subscriber_account_0 WHERE SUBSCRIBER_ID = :wdbsSubscriberAccount0 and CHARGE_RULE_ID= :charge0 ;",nativeQuery = true)
	public Integer delete(@Param("wdbsSubscriberAccount0") Long wdbsSubscriberAccount0,@Param("charge0") Long charge0);



	
	
	
	
	
	

}
