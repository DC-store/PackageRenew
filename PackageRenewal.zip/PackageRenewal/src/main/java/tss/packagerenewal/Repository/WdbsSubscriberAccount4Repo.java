package tss.packagerenewal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import tss.packagerenewal.Entity.WdbsSubscriberAccount4;



@Repository
public interface WdbsSubscriberAccount4Repo extends JpaRepository<WdbsSubscriberAccount4, Long> {

	
	
	@Query(value ="SELECT SUBSCRIBER_ID FROM wdbs_subscriber_account_4 WHERE SUBSCRIBER_ID = :subscriberId  ;" , nativeQuery = true)
	 public List<Long> findSubscriberId(@Param("subscriberId") Long subscriberId);

	
	
	


	@Query(value = "SELECT CHARGE_RULE_ID FROM wdbs_subscriber_account_4 WHERE SUBSCRIBER_ID = :subscriberId",nativeQuery = true)
	public List<Long> getChargeRule(@Param("subscriberId") Long subscriberId);




	
	
	



	@Transactional
	@Modifying 
	@Query(value = "DELETE FROM wdbs_subscriber_account_4 WHERE SUBSCRIBER_ID = :wdbsSubscriberAccount4 and CHARGE_RULE_ID= :charge4 ;",nativeQuery = true)
	public Integer delete(@Param("wdbsSubscriberAccount4") Long wdbsSubscriberAccount4,@Param("charge4") Long charge4);



}
