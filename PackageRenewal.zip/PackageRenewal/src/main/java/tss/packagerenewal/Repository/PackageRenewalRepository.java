package tss.packagerenewal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tss.packagerenewal.Model.RenewalEvr;
import tss.packagerenewal.gen.LoggingUtils;

@Repository
public interface PackageRenewalRepository extends JpaRepository<RenewalEvr, String> {
	static LoggingUtils logger = new LoggingUtils(PackageRenewalRepository.class.getName());

	@Modifying
    @Query(value = "UPDATE bb_evr_provisioning_renewal SET MODIFIELD_FLAG = 0 WHERE TRANSACTION_ID = :transactionId ;", nativeQuery = true)
	public int updateByTransactionId(@Param("transactionId") String transactionId);

	@Modifying
	@Query(value = "SELECT * FROM bb_evr_provisioning_renewal WHERE MODIFIELD_FLAG = 1", nativeQuery = true)
	public List<RenewalEvr> getAllEvrByModifiedFlag();

}
