package tss.packagerenewal.Repository;

import java.math.BigInteger;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tss.packagerenewal.Entity.WdbsPackageMastDAO;



@Repository

public interface WdbsPackageMastRepository extends JpaRepository<WdbsPackageMastDAO, BigInteger> {


	@Query(value="select PACKAGE_ID from wdbs_package_mast where PACKAGE_ID= :pack and  PACKAGE_CLASSIFY =0 ;" ,nativeQuery = true)
	public BigInteger fetchingPackageId(@Param("pack") BigInteger pack);

	@Query(value="select PACKAGE_ID from wdbs_package_mast where PACKAGE_ID= :pack and  PACKAGE_CLASSIFY =0 ;" ,nativeQuery = true)
	public BigInteger packageIdFetching(@Param("pack") BigInteger pack);

	
	
	
	
}
