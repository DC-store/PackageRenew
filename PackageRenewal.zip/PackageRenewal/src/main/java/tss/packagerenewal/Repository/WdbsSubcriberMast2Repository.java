package tss.packagerenewal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import tss.packagerenewal.Entity.WdbsSubcriberMast2;

@Repository
public interface WdbsSubcriberMast2Repository extends JpaRepository<WdbsSubcriberMast2, Long> {

	
	//@Query(value ="SELECT SUBSCRIBER_ID FROM wdbs_subscriber_mast_0 WHERE ", nativeQuery = true)
		 public WdbsSubcriberMast2 findBySubscriberId( long subscriberId);
		
		 @Query(value ="SELECT STATUS FROM wdbs_subscriber_mast_2 WHERE  SUBSCRIBER_ID = :subscriberId  ;" , nativeQuery = true)
		 public int findStatus(@Param("subscriberId") long subscriberId);

		 @Query(value ="SELECT MSISDN FROM wdbs_subscriber_mast_2 WHERE  SUBSCRIBER_ID = :subscriberId  ;" , nativeQuery = true)
		 public long findMsIsdn(@Param("subscriberId") long subscriberId);
}
