package tss.packagerenewal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import tss.packagerenewal.Entity.WdbsSubscriberAccount1;



@Repository
public interface WdbsSubscriberAccount1Repo extends JpaRepository<WdbsSubscriberAccount1, Long> {

	
	@Query(value ="SELECT SUBSCRIBER_ID FROM wdbs_subscriber_account_1 WHERE SUBSCRIBER_ID = :subscriberId  ;" , nativeQuery = true)
	 public List<Long> findSubscriberId(@Param("subscriberId") Long subscriberId);

	
	
	


	@Query(value = "SELECT CHARGE_RULE_ID FROM wdbs_subscriber_account_1 WHERE SUBSCRIBER_ID = :subscriberId",nativeQuery = true)
	public List<Long> getChargeRule(@Param("subscriberId") Long subscriberId);




	
	
	



	@Transactional
	@Modifying 
	@Query(value = "DELETE FROM wdbs_subscriber_account_1 WHERE SUBSCRIBER_ID = :wdbsSubscriberAccount1 and CHARGE_RULE_ID= :charge1 ;",nativeQuery = true)
	public Integer delete(@Param("wdbsSubscriberAccount1") Long wdbsSubscriberAccount1,@Param("charge1") Long charge1);



	
	
}
