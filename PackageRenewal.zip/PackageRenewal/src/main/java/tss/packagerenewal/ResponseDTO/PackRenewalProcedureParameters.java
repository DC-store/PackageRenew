package tss.packagerenewal.ResponseDTO;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.List;

public class PackRenewalProcedureParameters {
	// Pack Renewal param
	private BigInteger ftc_renewal_id; 
	private BigInteger ftc_package_id;  
	private BigInteger ftc_subscriber_id; 
	private int ftc_renew_count;  
	private String ftc_table_id;   
	private int ftc_renewalStatus;
	private int  ftc_nodeId;
	//PacakgeMast
	/*private int packageRepeat;
	private int packageRenewal;
	private Long packageMastId;
	private int graceperiod;
	private int ftc_packRenewCount;
	private Long ftc_calanderValidity; 
	private int ftc_packSubscriptionType; 
	private Long ftc_renewValidity;
	*/
	//private List<PackageMastDto> packageMastDtoList= new ArrayList<>();


	


	public int getFtc_renew_count() {
		return ftc_renew_count;
	}


	public BigInteger getFtc_renewal_id() {
		return ftc_renewal_id;
	}


	public void setFtc_renewal_id(BigInteger ftc_renewal_id) {
		this.ftc_renewal_id = ftc_renewal_id;
	}


	public BigInteger getFtc_package_id() {
		return ftc_package_id;
	}


	public void setFtc_package_id(BigInteger ftc_package_id) {
		this.ftc_package_id = ftc_package_id;
	}


	public BigInteger getFtc_subscriber_id() {
		return ftc_subscriber_id;
	}


	public void setFtc_subscriber_id(BigInteger ftc_subscriber_id) {
		this.ftc_subscriber_id = ftc_subscriber_id;
	}


	public void setFtc_renew_count(int ftc_renew_count) {
		this.ftc_renew_count = ftc_renew_count;
	}




	public String getFtc_table_id() {
		return ftc_table_id;
	}


	public void setFtc_table_id(String ftc_table_id) {
		this.ftc_table_id = ftc_table_id;
	}


	public int getFtc_renewalStatus() {
		return ftc_renewalStatus;
	}


	public void setFtc_renewalStatus(int ftc_renewalStatus) {
		this.ftc_renewalStatus = ftc_renewalStatus;
	}


	

	public int getFtc_nodeId() {
		return ftc_nodeId;
	}


	public void setFtc_nodeId(int ftc_nodeId) {
		this.ftc_nodeId = ftc_nodeId;
	}


	

}
