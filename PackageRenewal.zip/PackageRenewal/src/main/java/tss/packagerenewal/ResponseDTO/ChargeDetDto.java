package tss.packagerenewal.ResponseDTO;

public class ChargeDetDto {
	private Long ftc_from_range;  
	private Long ftc_to_range;
	public Long getFtc_from_range() {
		return ftc_from_range;
	}
	public void setFtc_from_range(Long ftc_from_range) {
		this.ftc_from_range = ftc_from_range;
	}
	public Long getFtc_to_range() {
		return ftc_to_range;
	}
	public void setFtc_to_range(Long ftc_to_range) {
		this.ftc_to_range = ftc_to_range;
	} 
	
	
}
