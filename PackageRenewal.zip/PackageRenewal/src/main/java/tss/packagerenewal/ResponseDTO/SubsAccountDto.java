package tss.packagerenewal.ResponseDTO;

import java.util.Date;

public class SubsAccountDto {
	//Account
		private Long ftc_account;    
		private Long ftc_accumulated_account;  	
		private Long ftc_oldaccumulated_account;  
		private Date ftc_to_date; 
		private Long ftc_usage;  
		private int ftc_graceApplied;
		private Long ftc_from_range;  
		private Long ftc_to_range;
		private int ftc_saStatus;
		
		private Long ftc_chargeRuleId; 
		private PackageMastDto packageMastDto = new PackageMastDto();
		
		private PackageRenewalDto packageRenewalDto = new PackageRenewalDto();
		private ChargingRulesDto chargingRulesDto = new ChargingRulesDto();
		
		
		public Long getFtc_account() {
			return ftc_account;
		}
		public void setFtc_account(Long ftc_account) {
			this.ftc_account = ftc_account;
		}
		public Long getFtc_accumulated_account() {
			return ftc_accumulated_account;
		}
		public void setFtc_accumulated_account(Long ftc_accumulated_account) {
			this.ftc_accumulated_account = ftc_accumulated_account;
		}
		public Long getFtc_oldaccumulated_account() {
			return ftc_oldaccumulated_account;
		}
		public void setFtc_oldaccumulated_account(Long ftc_oldaccumulated_account) {
			this.ftc_oldaccumulated_account = ftc_oldaccumulated_account;
		}
		public Date getFtc_to_date() {
			return ftc_to_date;
		}
		public void setFtc_to_date(Date ftc_to_date) {
			this.ftc_to_date = ftc_to_date;
		}
		public Long getFtc_usage() {
			return ftc_usage;
		}
		public void setFtc_usage(Long ftc_usage) {
			this.ftc_usage = ftc_usage;
		}
		public int getFtc_graceApplied() {
			return ftc_graceApplied;
		}
		public void setFtc_graceApplied(int ftc_graceApplied) {
			this.ftc_graceApplied = ftc_graceApplied;
		}
		public Long getFtc_from_range() {
			return ftc_from_range;
		}
		public void setFtc_from_range(Long ftc_from_range) {
			this.ftc_from_range = ftc_from_range;
		}
		public Long getFtc_to_range() {
			return ftc_to_range;
		}
		public void setFtc_to_range(Long ftc_to_range) {
			this.ftc_to_range = ftc_to_range;
		}
		public int getFtc_saStatus() {
			return ftc_saStatus;
		}
		public void setFtc_saStatus(int ftc_saStatus) {
			this.ftc_saStatus = ftc_saStatus;
		}
		public Long getFtc_chargeRuleId() {
			return ftc_chargeRuleId;
		}
		public void setFtc_chargeRuleId(Long ftc_chargeRuleId) {
			this.ftc_chargeRuleId = ftc_chargeRuleId;
		}
		public PackageMastDto getPackageMastDto() {
			return packageMastDto;
		}
		public void setPackageMastDto(PackageMastDto packageMastDto) {
			this.packageMastDto = packageMastDto;
		}
		public PackageRenewalDto getPackageRenewalDto() {
			return packageRenewalDto;
		}
		public void setPackageRenewalDto(PackageRenewalDto packageRenewalDto) {
			this.packageRenewalDto = packageRenewalDto;
		}
		public ChargingRulesDto getChargingRulesDto() {
			return chargingRulesDto;
		}
		public void setChargingRulesDto(ChargingRulesDto chargingRulesDto) {
			this.chargingRulesDto = chargingRulesDto;
		} 
		
		
}
