package tss.packagerenewal.ResponseDTO;

import java.util.Date;

public class PackageRenewalDto {
	private Long ftc_renewal_id; 
	private Long ftc_package_id;  
	private Long ftc_subscriber_id; 
	private int ftc_renew_count;  
	private int ftc_tabId;   
	private int ftc_renewalStatus;
	
	public Long getFtc_renewal_id() {
		return ftc_renewal_id;
	}
	public void setFtc_renewal_id(Long ftc_renewal_id) {
		this.ftc_renewal_id = ftc_renewal_id;
	}
	public Long getFtc_package_id() {
		return ftc_package_id;
	}
	public void setFtc_package_id(Long ftc_package_id) {
		this.ftc_package_id = ftc_package_id;
	}
	public Long getFtc_subscriber_id() {
		return ftc_subscriber_id;
	}
	public void setFtc_subscriber_id(Long ftc_subscriber_id) {
		this.ftc_subscriber_id = ftc_subscriber_id;
	}
	public int getFtc_renew_count() {
		return ftc_renew_count;
	}
	public void setFtc_renew_count(int ftc_renew_count) {
		this.ftc_renew_count = ftc_renew_count;
	}
	public int getFtc_tabId() {
		return ftc_tabId;
	}
	public void setFtc_tabId(int ftc_tabId) {
		this.ftc_tabId = ftc_tabId;
	}
	public int getFtc_renewalStatus() {
		return ftc_renewalStatus;
	}
	public void setFtc_renewalStatus(int ftc_renewalStatus) {
		this.ftc_renewalStatus = ftc_renewalStatus;
	}     
	
}
