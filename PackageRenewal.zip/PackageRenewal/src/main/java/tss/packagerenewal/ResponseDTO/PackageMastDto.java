package tss.packagerenewal.ResponseDTO;

import java.util.ArrayList;
import java.util.List;

public class PackageMastDto {
	private int packageRepeat;
	private int packageRenewal;
	private Long packageMastId;
	private int graceperiod;
	private int ftc_packRenewCount;
	private Long ftc_calanderValidity; 
	private int ftc_packSubscriptionType; 
	private Long ftc_renewValidity;
	
	private List<ChargingRulesDto> chargingRulesDtoList= new ArrayList<>();
	
	public int getPackageRepeat() {
		return packageRepeat;
	}
	public void setPackageRepeat(int packageRepeat) {
		this.packageRepeat = packageRepeat;
	}
	public int getPackageRenewal() {
		return packageRenewal;
	}
	public void setPackageRenewal(int packageRenewal) {
		this.packageRenewal = packageRenewal;
	}
	public Long getPackageMastId() {
		return packageMastId;
	}
	public void setPackageMastId(Long packageMastId) {
		this.packageMastId = packageMastId;
	}
	public int getGraceperiod() {
		return graceperiod;
	}
	public void setGraceperiod(int graceperiod) {
		this.graceperiod = graceperiod;
	}
	public int getFtc_packRenewCount() {
		return ftc_packRenewCount;
	}
	public void setFtc_packRenewCount(int ftc_packRenewCount) {
		this.ftc_packRenewCount = ftc_packRenewCount;
	}
	public Long getFtc_calanderValidity() {
		return ftc_calanderValidity;
	}
	public void setFtc_calanderValidity(Long ftc_calanderValidity) {
		this.ftc_calanderValidity = ftc_calanderValidity;
	}
	public int getFtc_packSubscriptionType() {
		return ftc_packSubscriptionType;
	}
	public void setFtc_packSubscriptionType(int ftc_packSubscriptionType) {
		this.ftc_packSubscriptionType = ftc_packSubscriptionType;
	}
	public Long getFtc_renewValidity() {
		return ftc_renewValidity;
	}
	public void setFtc_renewValidity(Long ftc_renewValidity) {
		this.ftc_renewValidity = ftc_renewValidity;
	}
	public List<ChargingRulesDto> getChargingRulesDtoList() {
		return chargingRulesDtoList;
	}
	public void setChargingRulesDtoList(List<ChargingRulesDto> chargingRulesDtoList) {
		this.chargingRulesDtoList = chargingRulesDtoList;
	}   
	     
	  
			
	     
}
