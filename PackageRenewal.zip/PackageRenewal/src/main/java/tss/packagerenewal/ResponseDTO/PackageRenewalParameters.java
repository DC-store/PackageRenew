package tss.packagerenewal.ResponseDTO;

import java.math.BigInteger;
import java.util.Date;

public class PackageRenewalParameters {
	    
	
	//private int r_table_id;
	
	//private Long r_subscriber_id;
	
	//private Long r_package_id; 
	private Long ftc_renewal_id; 
	private Long ftc_package_id;  
	private Long ftc_subscriber_id; 
	private int ftc_renew_count;  
	private int ftc_tabId;   
	private int ftc_renewalStatus; 
	
	//Account
	private Long ftc_account;    
	private Long ftc_accumulated_account;  	
	private Long ftc_oldaccumulated_account;  
	private Date ftc_to_date; 
	private Long ftc_usage;  
	private int ftc_graceApplied;
	private Long ftc_from_range;  
	private Long ftc_to_range; 
	//private int api_code = 121;
	    
	//private String transactionId;
	private Long ftc_msisdn;  //Profile
	
	

	private int subscriberMastType;
	private int AllCheckcase1;
	private int graceperiod;
	private String ftc_table_id;
	private String tableName;
	private String toDateConc; 
	private Long accumatedAddition;  
	private Long accountbalance;  
	private int ftc_packRenewCount;
	// DECLARE done INT DEFAULT FALSE;
	private int ftc_saStatus;
	private Long ftc_calanderValidity; 
	private int ftc_packSubscriptionType; 
	private Long ftc_renewValidity; 
	private int ftc_nodeId; 
	private Long ftc_chargeRuleId; 
	private int ftc_chargeId; 
	private String submasttableName; 
	private Long varcount; 
	private Long packmastcount;   
	private Long crcount;  
	
	private Date startTime; 
	private Date endTime; 
	private int executionTime;
	private Long listOfSubcriberInRenewal;
	
	private Long ftcMsisdn;
	private Long subscriberSMType;
	public Long getFtc_renewal_id() {
		return ftc_renewal_id;
	}
	public void setFtc_renewal_id(Long ftc_renewal_id) {
		this.ftc_renewal_id = ftc_renewal_id;
	}
	public Long getFtc_package_id() {
		return ftc_package_id;
	}
	public void setFtc_package_id(Long ftc_package_id) {
		this.ftc_package_id = ftc_package_id;
	}
	public Long getFtc_subscriber_id() {
		return ftc_subscriber_id;
	}
	public void setFtc_subscriber_id(Long ftc_subscriber_id) {
		this.ftc_subscriber_id = ftc_subscriber_id;
	}
	public int getFtc_renew_count() {
		return ftc_renew_count;
	}
	public void setFtc_renew_count(int ftc_renew_count) {
		this.ftc_renew_count = ftc_renew_count;
	}
	public int getFtc_tabId() {
		return ftc_tabId;
	}
	public void setFtc_tabId(int ftc_tabId) {
		this.ftc_tabId = ftc_tabId;
	}
	public int getFtc_renewalStatus() {
		return ftc_renewalStatus;
	}
	public void setFtc_renewalStatus(int ftc_renewalStatus) {
		this.ftc_renewalStatus = ftc_renewalStatus;
	}
	public Long getFtc_account() {
		return ftc_account;
	}
	public void setFtc_account(Long ftc_account) {
		this.ftc_account = ftc_account;
	}
	public Long getFtc_accumulated_account() {
		return ftc_accumulated_account;
	}
	public void setFtc_accumulated_account(Long ftc_accumulated_account) {
		this.ftc_accumulated_account = ftc_accumulated_account;
	}
	public Long getFtc_oldaccumulated_account() {
		return ftc_oldaccumulated_account;
	}
	public void setFtc_oldaccumulated_account(Long ftc_oldaccumulated_account) {
		this.ftc_oldaccumulated_account = ftc_oldaccumulated_account;
	}
	public Date getFtc_to_date() {
		return ftc_to_date;
	}
	public void setFtc_to_date(Date ftc_to_date) {
		this.ftc_to_date = ftc_to_date;
	}
	public Long getFtc_usage() {
		return ftc_usage;
	}
	public void setFtc_usage(Long ftc_usage) {
		this.ftc_usage = ftc_usage;
	}
	public int getFtc_graceApplied() {
		return ftc_graceApplied;
	}
	public void setFtc_graceApplied(int ftc_graceApplied) {
		this.ftc_graceApplied = ftc_graceApplied;
	}
	public Long getFtc_from_range() {
		return ftc_from_range;
	}
	public void setFtc_from_range(Long ftc_from_range) {
		this.ftc_from_range = ftc_from_range;
	}
	public Long getFtc_to_range() {
		return ftc_to_range;
	}
	public void setFtc_to_range(Long ftc_to_range) {
		this.ftc_to_range = ftc_to_range;
	}
	public Long getFtc_msisdn() {
		return ftc_msisdn;
	}
	public void setFtc_msisdn(Long ftc_msisdn) {
		this.ftc_msisdn = ftc_msisdn;
	}
	public int getSubscriberMastType() {
		return subscriberMastType;
	}
	public void setSubscriberMastType(int subscriberMastType) {
		this.subscriberMastType = subscriberMastType;
	}
	public int getAllCheckcase1() {
		return AllCheckcase1;
	}
	public void setAllCheckcase1(int allCheckcase1) {
		AllCheckcase1 = allCheckcase1;
	}
	public int getGraceperiod() {
		return graceperiod;
	}
	public void setGraceperiod(int graceperiod) {
		this.graceperiod = graceperiod;
	}
	public String getFtc_table_id() {
		return ftc_table_id;
	}
	public void setFtc_table_id(String ftc_table_id) {
		this.ftc_table_id = ftc_table_id;
	}
	public String getTableName() {
		return tableName;
	}
	public void setTableName(String tableName) {
		this.tableName = tableName;
	}
	public String getToDateConc() {
		return toDateConc;
	}
	public void setToDateConc(String toDateConc) {
		this.toDateConc = toDateConc;
	}
	public Long getAccumatedAddition() {
		return accumatedAddition;
	}
	public void setAccumatedAddition(Long accumatedAddition) {
		this.accumatedAddition = accumatedAddition;
	}
	public Long getAccountbalance() {
		return accountbalance;
	}
	public void setAccountbalance(Long accountbalance) {
		this.accountbalance = accountbalance;
	}
	public int getFtc_packRenewCount() {
		return ftc_packRenewCount;
	}
	public void setFtc_packRenewCount(int ftc_packRenewCount) {
		this.ftc_packRenewCount = ftc_packRenewCount;
	}
	public int getFtc_saStatus() {
		return ftc_saStatus;
	}
	public void setFtc_saStatus(int ftc_saStatus) {
		this.ftc_saStatus = ftc_saStatus;
	}
	public Long getFtc_calanderValidity() {
		return ftc_calanderValidity;
	}
	public void setFtc_calanderValidity(Long ftc_calanderValidity) {
		this.ftc_calanderValidity = ftc_calanderValidity;
	}
	public int getFtc_packSubscriptionType() {
		return ftc_packSubscriptionType;
	}
	public void setFtc_packSubscriptionType(int ftc_packSubscriptionType) {
		this.ftc_packSubscriptionType = ftc_packSubscriptionType;
	}
	public Long getFtc_renewValidity() {
		return ftc_renewValidity;
	}
	public void setFtc_renewValidity(Long ftc_renewValidity) {
		this.ftc_renewValidity = ftc_renewValidity;
	}
	public int getFtc_nodeId() {
		return ftc_nodeId;
	}
	public void setFtc_nodeId(int ftc_nodeId) {
		this.ftc_nodeId = ftc_nodeId;
	}
	public Long getFtc_chargeRuleId() {
		return ftc_chargeRuleId;
	}
	public void setFtc_chargeRuleId(Long ftc_chargeRuleId) {
		this.ftc_chargeRuleId = ftc_chargeRuleId;
	}
	public int getFtc_chargeId() {
		return ftc_chargeId;
	}
	public void setFtc_chargeId(int ftc_chargeId) {
		this.ftc_chargeId = ftc_chargeId;
	}
	public String getSubmasttableName() {
		return submasttableName;
	}
	public void setSubmasttableName(String submasttableName) {
		this.submasttableName = submasttableName;
	}
	public Long getVarcount() {
		return varcount;
	}
	public void setVarcount(Long varcount) {
		this.varcount = varcount;
	}
	public Long getPackmastcount() {
		return packmastcount;
	}
	public void setPackmastcount(Long packmastcount) {
		this.packmastcount = packmastcount;
	}
	public Long getCrcount() {
		return crcount;
	}
	public void setCrcount(Long crcount) {
		this.crcount = crcount;
	}
	public Date getStartTime() {
		return startTime;
	}
	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public int getExecutionTime() {
		return executionTime;
	}
	public void setExecutionTime(int executionTime) {
		this.executionTime = executionTime;
	}
	public Long getListOfSubcriberInRenewal() {
		return listOfSubcriberInRenewal;
	}
	public void setListOfSubcriberInRenewal(Long listOfSubcriberInRenewal) {
		this.listOfSubcriberInRenewal = listOfSubcriberInRenewal;
	}
	public Long getFtcMsisdn() {
		return ftcMsisdn;
	}
	public void setFtcMsisdn(Long ftcMsisdn) {
		this.ftcMsisdn = ftcMsisdn;
	}
	public Long getSubscriberSMType() {
		return subscriberSMType;
	}
	public void setSubscriberSMType(Long subscriberSMType) {
		this.subscriberSMType = subscriberSMType;
	}
	
	
	
	
	
	     
}
