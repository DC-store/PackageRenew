package tss.packagerenewal.ResponseDTO;

import java.util.ArrayList;
import java.util.List;

public class ChargingRulesDto {
	
	private Long ftc_chargeRuleId; 
	private Long ftc_package_id; 
	
	private List<ChargeDetDto> chargeDetDtoList= new ArrayList<>();
	
	private int ftc_chargeId;

	public Long getFtc_chargeRuleId() {
		return ftc_chargeRuleId;
	}

	public void setFtc_chargeRuleId(Long ftc_chargeRuleId) {
		this.ftc_chargeRuleId = ftc_chargeRuleId;
	}

	public Long getFtc_package_id() {
		return ftc_package_id;
	}

	public void setFtc_package_id(Long ftc_package_id) {
		this.ftc_package_id = ftc_package_id;
	}

	public int getFtc_chargeId() {
		return ftc_chargeId;
	}

	public void setFtc_chargeId(int ftc_chargeId) {
		this.ftc_chargeId = ftc_chargeId;
	}

	public List<ChargeDetDto> getChargeDetDtoList() {
		return chargeDetDtoList;
	}

	public void setChargeDetDtoList(List<ChargeDetDto> chargeDetDtoList) {
		this.chargeDetDtoList = chargeDetDtoList;
	} 
	
	
	
}
