package tss.packagerenewal.ResponseDTO;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.Date;

public class ResponseDto {

	private String oldMac;

	private String transactionId;

	private String newMac;

	private String addOnName;

	private String addOnValue;

	private String macUsername;

	private String serviceOperation;

	private Long incomingData;

	private Long outgoingData;

	private String serviceNo;

	private Integer cityID;

	private Integer districtID;

	private Integer neighborhoodID;

	private Integer streetID;

	private Integer cmtsOLTID;

	private Long secureInternetProfileID;

	private String ipv4;

	private String ipv6;

	private Long sEQNO;

	private String subIdentifier;

	private String accountId;

	private Long subscriberId;

	private String imei;

	private String imsi;

	private int subscriptionType;

	private String customerType;

	private String cosId;

	private Long applicationId;

	private Long cdrType;

	private LocalDateTime TIMESTAMP;
	private LocalDateTime SERVICE_START_TIME;
	private LocalDateTime SERVICE_END_TIME;

	private String sessionId;

	private String sgsnIp;

	private String sgsnMccMnc;

	private String sgsnTadig;

	private String apn;

	private String locationAccess;

	private Long accessType;

	private String chargingId;

	private Long ratingGroup;

	private String serviceIdentifier;

	private Integer packageId;

	private String bucketId;

	private Long serviceReqCount;

	private Long chargeUsed;

	private String otherSubIdentifier;

	private Integer resultCode;

	private String inReferenceId;

	private Long downlinkKBytes;

	private Long uplinkKBytes;

	private String actualCommUsedRef;

	private Long totalCommAccounted;

	private Long commType;

	private Long charge;

	private Long totalTax;

	private String reserved1;

	private String reserved2;

	private String reserved3;

	private String reserved4;

	private String timeZone;

	private String apiUsername;

	private Integer nodeId;

	private String clientIpAddress;

	private Integer apiCode;

	private Long quotaDuration;

	private String quotaCounter;

	private String value;

	private String renewalStatus;

	private BigInteger renewalCount;

	private Date evrTimeStamp;

	public Date getEvrTimeStamp() {
		return evrTimeStamp;
	}

	public void setEvrTimeStamp(Date evrTimeStamp) {
		this.evrTimeStamp = evrTimeStamp;
	}

	public String getOldMac() {
		return oldMac;
	}

	public void setOldMac(String oldMac) {
		this.oldMac = oldMac;
	}

	public String getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}

	public String getNewMac() {
		return newMac;
	}

	public void setNewMac(String newMac) {
		this.newMac = newMac;
	}

	public String getAddOnName() {
		return addOnName;
	}

	public void setAddOnName(String addOnName) {
		this.addOnName = addOnName;
	}

	public String getAddOnValue() {
		return addOnValue;
	}

	public void setAddOnValue(String addOnValue) {
		this.addOnValue = addOnValue;
	}

	public String getMacUsername() {
		return macUsername;
	}

	public void setMacUsername(String macUsername) {
		this.macUsername = macUsername;
	}

	public String getServiceOperation() {
		return serviceOperation;
	}

	public void setServiceOperation(String serviceOperation) {
		this.serviceOperation = serviceOperation;
	}

	public Long getIncomingData() {
		return incomingData;
	}

	public void setIncomingData(Long incomingData) {
		this.incomingData = incomingData;
	}

	public Long getOutgoingData() {
		return outgoingData;
	}

	public void setOutgoingData(Long outgoingData) {
		this.outgoingData = outgoingData;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	public Integer getCityID() {
		return cityID;
	}

	public void setCityID(Integer cityID) {
		this.cityID = cityID;
	}

	public Integer getDistrictID() {
		return districtID;
	}

	public void setDistrictID(Integer districtID) {
		this.districtID = districtID;
	}

	public Integer getNeighborhoodID() {
		return neighborhoodID;
	}

	public void setNeighborhoodID(Integer neighborhoodID) {
		this.neighborhoodID = neighborhoodID;
	}

	public Integer getStreetID() {
		return streetID;
	}

	public void setStreetID(Integer streetID) {
		this.streetID = streetID;
	}

	public Integer getCmtsOLTID() {
		return cmtsOLTID;
	}

	public void setCmtsOLTID(Integer cmtsOLTID) {
		this.cmtsOLTID = cmtsOLTID;
	}

	public Long getSecureInternetProfileID() {
		return secureInternetProfileID;
	}

	public void setSecureInternetProfileID(Long secureInternetProfileID) {
		this.secureInternetProfileID = secureInternetProfileID;
	}

	public String getIpv4() {
		return ipv4;
	}

	public void setIpv4(String ipv4) {
		this.ipv4 = ipv4;
	}

	public String getIpv6() {
		return ipv6;
	}

	public void setIpv6(String ipv6) {
		this.ipv6 = ipv6;
	}

	public Long getsEQNO() {
		return sEQNO;
	}

	public void setsEQNO(Long sEQNO) {
		this.sEQNO = sEQNO;
	}

	public String getSubIdentifier() {
		return subIdentifier;
	}

	public void setSubIdentifier(String subIdentifier) {
		this.subIdentifier = subIdentifier;
	}

	public String getAccountId() {
		return accountId;
	}

	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}

	public Long getSubscriberId() {
		return subscriberId;
	}

	public void setSubscriberId(Long subscriberId) {
		this.subscriberId = subscriberId;
	}

	public String getImei() {
		return imei;
	}

	public void setImei(String imei) {
		this.imei = imei;
	}

	public String getImsi() {
		return imsi;
	}

	public void setImsi(String imsi) {
		this.imsi = imsi;
	}

	public int getSubscriptionType() {
		return subscriptionType;
	}

	public void setSubscriptionType(int subscriptionType) {
		this.subscriptionType = subscriptionType;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getCosId() {
		return cosId;
	}

	public void setCosId(String cosId) {
		this.cosId = cosId;
	}

	public Long getApplicationId() {
		return applicationId;
	}

	public void setApplicationId(Long applicationId) {
		this.applicationId = applicationId;
	}

	public Long getCdrType() {
		return cdrType;
	}

	public void setCdrType(Long cdrType) {
		this.cdrType = cdrType;
	}

	public LocalDateTime getTIMESTAMP() {
		return TIMESTAMP;
	}

	public void setTIMESTAMP(LocalDateTime tIMESTAMP) {
		TIMESTAMP = tIMESTAMP;
	}

	public LocalDateTime getSERVICE_START_TIME() {
		return SERVICE_START_TIME;
	}

	public void setSERVICE_START_TIME(LocalDateTime sERVICE_START_TIME) {
		SERVICE_START_TIME = sERVICE_START_TIME;
	}

	public LocalDateTime getSERVICE_END_TIME() {
		return SERVICE_END_TIME;
	}

	public void setSERVICE_END_TIME(LocalDateTime sERVICE_END_TIME) {
		SERVICE_END_TIME = sERVICE_END_TIME;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getSgsnIp() {
		return sgsnIp;
	}

	public void setSgsnIp(String sgsnIp) {
		this.sgsnIp = sgsnIp;
	}

	public String getSgsnMccMnc() {
		return sgsnMccMnc;
	}

	public void setSgsnMccMnc(String sgsnMccMnc) {
		this.sgsnMccMnc = sgsnMccMnc;
	}

	public String getSgsnTadig() {
		return sgsnTadig;
	}

	public void setSgsnTadig(String sgsnTadig) {
		this.sgsnTadig = sgsnTadig;
	}

	public String getApn() {
		return apn;
	}

	public void setApn(String apn) {
		this.apn = apn;
	}

	public String getLocationAccess() {
		return locationAccess;
	}

	public void setLocationAccess(String locationAccess) {
		this.locationAccess = locationAccess;
	}

	public Long getAccessType() {
		return accessType;
	}

	public void setAccessType(Long accessType) {
		this.accessType = accessType;
	}

	public String getChargingId() {
		return chargingId;
	}

	public void setChargingId(String chargingId) {
		this.chargingId = chargingId;
	}

	public Long getRatingGroup() {
		return ratingGroup;
	}

	public void setRatingGroup(Long ratingGroup) {
		this.ratingGroup = ratingGroup;
	}

	public String getServiceIdentifier() {
		return serviceIdentifier;
	}

	public void setServiceIdentifier(String serviceIdentifier) {
		this.serviceIdentifier = serviceIdentifier;
	}

	public Integer getPackageId() {
		return packageId;
	}

	public void setPackageId(Integer packageId) {
		this.packageId = packageId;
	}

	public String getBucketId() {
		return bucketId;
	}

	public void setBucketId(String bucketId) {
		this.bucketId = bucketId;
	}

	public Long getServiceReqCount() {
		return serviceReqCount;
	}

	public void setServiceReqCount(Long serviceReqCount) {
		this.serviceReqCount = serviceReqCount;
	}

	public Long getChargeUsed() {
		return chargeUsed;
	}

	public void setChargeUsed(Long chargeUsed) {
		this.chargeUsed = chargeUsed;
	}

	public String getOtherSubIdentifier() {
		return otherSubIdentifier;
	}

	public void setOtherSubIdentifier(String otherSubIdentifier) {
		this.otherSubIdentifier = otherSubIdentifier;
	}

	public Integer getResultCode() {
		return resultCode;
	}

	public void setResultCode(Integer resultCode) {
		this.resultCode = resultCode;
	}

	public String getInReferenceId() {
		return inReferenceId;
	}

	public void setInReferenceId(String inReferenceId) {
		this.inReferenceId = inReferenceId;
	}

	public Long getDownlinkKBytes() {
		return downlinkKBytes;
	}

	public void setDownlinkKBytes(Long downlinkKBytes) {
		this.downlinkKBytes = downlinkKBytes;
	}

	public Long getUplinkKBytes() {
		return uplinkKBytes;
	}

	public void setUplinkKBytes(Long uplinkKBytes) {
		this.uplinkKBytes = uplinkKBytes;
	}

	public String getActualCommUsedRef() {
		return actualCommUsedRef;
	}

	public void setActualCommUsedRef(String actualCommUsedRef) {
		this.actualCommUsedRef = actualCommUsedRef;
	}

	public Long getTotalCommAccounted() {
		return totalCommAccounted;
	}

	public void setTotalCommAccounted(Long totalCommAccounted) {
		this.totalCommAccounted = totalCommAccounted;
	}

	public Long getCommType() {
		return commType;
	}

	public void setCommType(Long commType) {
		this.commType = commType;
	}

	public Long getCharge() {
		return charge;
	}

	public void setCharge(Long charge) {
		this.charge = charge;
	}

	public Long getTotalTax() {
		return totalTax;
	}

	public void setTotalTax(Long totalTax) {
		this.totalTax = totalTax;
	}

	public String getReserved1() {
		return reserved1;
	}

	public void setReserved1(String reserved1) {
		this.reserved1 = reserved1;
	}

	public String getReserved2() {
		return reserved2;
	}

	public void setReserved2(String reserved2) {
		this.reserved2 = reserved2;
	}

	public String getReserved3() {
		return reserved3;
	}

	public void setReserved3(String reserved3) {
		this.reserved3 = reserved3;
	}

	public String getReserved4() {
		return reserved4;
	}

	public void setReserved4(String reserved4) {
		this.reserved4 = reserved4;
	}

	public String getTimeZone() {
		return timeZone;
	}

	public void setTimeZone(String timeZone) {
		this.timeZone = timeZone;
	}

	public String getApiUsername() {
		return apiUsername;
	}

	public void setApiUsername(String apiUsername) {
		this.apiUsername = apiUsername;
	}

	public Integer getNodeId() {
		return nodeId;
	}

	public void setNodeId(Integer nodeId) {
		this.nodeId = nodeId;
	}

	public String getClientIpAddress() {
		return clientIpAddress;
	}

	public void setClientIpAddress(String clientIpAddress) {
		this.clientIpAddress = clientIpAddress;
	}

	public Integer getApiCode() {
		return apiCode;
	}

	public void setApiCode(Integer apiCode) {
		this.apiCode = apiCode;
	}

	public Long getQuotaDuration() {
		return quotaDuration;
	}

	public void setQuotaDuration(Long quotaDuration) {
		this.quotaDuration = quotaDuration;
	}

	public String getQuotaCounter() {
		return quotaCounter;
	}

	public void setQuotaCounter(String quotaCounter) {
		this.quotaCounter = quotaCounter;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getRenewalStatus() {
		return renewalStatus;
	}

	public void setRenewalStatus(String renewalStatus) {
		this.renewalStatus = renewalStatus;
	}

	public BigInteger getRenewalCount() {
		return renewalCount;
	}

	public void setRenewalCount(BigInteger renewalCount) {
		this.renewalCount = renewalCount;
	}

}
