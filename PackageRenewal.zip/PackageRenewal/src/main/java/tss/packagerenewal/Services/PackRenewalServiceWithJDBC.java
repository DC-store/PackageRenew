/*
 * package tss.packagerenewal.Services;
 * 
 * import java.sql.Connection; import java.sql.DriverManager; import
 * java.sql.PreparedStatement; import java.sql.ResultSet; import
 * java.sql.SQLException; import java.util.ArrayList; import java.util.List;
 * 
 * import tss.packagerenewal.gen.APINames; import
 * tss.packagerenewal.gen.LoggingUtils;
 * 
 * import java.sql.*; import java.util.ArrayList; import java.util.List; import
 * java.math.BigInteger;
 * 
 * public class PackRenewalServiceWithJDBC { int apiCode =
 * APINames.API_RENEWAL_SERVICE; String nodeId = System.getenv("APP_NODE_ID");
 * // String nodeId = "01"; // static LoggingUtils logger = new
 * LoggingUtils(PackRenewalServiceWithJDBC.class.getName()); String url =
 * "jdbc:mysql://10.0.0.253:3306/rel_pcrfdb"; // Replace "mydatabase" with your
 * database name String username = "dev_wdbs"; // Replace with your MySQL
 * username String password = "dev_wdbs@T4y4n4"; // Replace with your MySQL
 * password
 * 
 * public void executePackageRenewalQuery() { String queryString =
 * "SELECT RENEW_ID, PACKAGE_ID, SUBSCRIBER_ID, RENEW_COUNT, `STATUS`, TABLE_ID, NODE_ID FROM wdbs_package_renewal "
 * + "WHERE `STATUS` = 1 AND NEXT_PROV_DATE <= SYSDATE() + INTERVAL 5 MINUTE;";
 * 
 * try { // Load the MySQL JDBC driver
 * Class.forName("com.mysql.cj.jdbc.Driver");
 * 
 * // Establish the connection Connection connection =
 * DriverManager.getConnection(url, username, password);
 * 
 * PreparedStatement statement = connection.prepareStatement(queryString); int
 * batchSize = 1000; statement.setFetchSize(batchSize);
 * 
 * ResultSet resultSet = statement.executeQuery();
 * 
 * List<Object[]> batchList = new ArrayList<>(); int count = 0;
 * 
 * while (resultSet.next()) { Object[] row = new Object[7];
 * 
 * row[0] = resultSet.getObject("RENEW_ID"); row[1] =
 * resultSet.getObject("PACKAGE_ID"); row[2] =
 * resultSet.getObject("SUBSCRIBER_ID"); row[3] =
 * resultSet.getInt("RENEW_COUNT"); row[4] = resultSet.getInt("STATUS"); row[5]
 * = resultSet.getString("TABLE_ID"); row[6] = resultSet.getInt("NODE_ID");
 * 
 * batchList.add(row); count++;
 * 
 * if (count % batchSize == 0) { processBatch(batchList, connection);
 * batchList.clear(); } }
 * 
 * // Process the remaining rows if (!batchList.isEmpty()) {
 * processBatch(batchList, connection); }
 * 
 * // Close the resources resultSet.close(); statement.close();
 * connection.close(); } catch (ClassNotFoundException | SQLException e) {
 * e.printStackTrace(); logger.error("Renewal Data==========Error: " +
 * e.getMessage()); } }
 * 
 * private void processBatch(List<Object[]> batchList, Connection connection) {
 * try { String procQuery =
 * "CALL MainUpdatePackageRenewal(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
 * PreparedStatement statement = connection.prepareStatement(procQuery);
 * 
 * for (Object[] row : batchList) { // Set the parameter values for each batch
 * row // statement.setString(1, System.getenv("APP_NODE_ID")); // nodeId
 * statement.setString(1, "01"); // nodeId statement.setInt(2, apiCode); //
 * apiCode statement.setObject(3, row[0]); // Ftc_renewal_id
 * statement.setObject(4, row[1]); // Ftc_package_id statement.setObject(5,
 * row[2]); // Ftc_subscriber_id statement.setInt(6, (Integer) row[3]); //
 * Ftc_renew_count statement.setInt(7, (Integer) row[4]); // Ftc_renewalStatus
 * statement.setString(8, (String) row[5]); // Ftc_table_id statement.setInt(9,
 * (Integer) row[6]); // Ftc_nodeId // statement.registerOutParameter(10,
 * Types.INTEGER); // ResultDbCode //statement.registerOutParameter(11,
 * Types.VARCHAR); // DbTxn // statement.registerOutParameter(12,
 * Types.VARCHAR); // DbLog
 * 
 * statement.addBatch(); }
 * 
 * statement.executeBatch(); statement.close(); } catch (SQLException e) {
 * e.printStackTrace(); logger.error("Renewal Data==========Error: " +
 * e.getMessage()); } } }
 * 
 * 
 * 
 */