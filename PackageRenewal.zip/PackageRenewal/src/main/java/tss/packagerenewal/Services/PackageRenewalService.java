//Java 8
package tss.packagerenewal.Services;

import java.math.BigInteger;
import java.sql.Connection;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import javax.persistence.EntityManager;
import javax.persistence.ParameterMode;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.StoredProcedureQuery;

import org.hibernate.Session;
import org.springframework.transaction.interceptor.TransactionAspectSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;


import tss.packagerenewal.Model.EVRBean;
import tss.packagerenewal.Repository.PackageRenewalRepository;
import tss.packagerenewal.ResponseDTO.PackRenewalProcedureParameters;
import tss.packagerenewal.ResponseDTO.ResponseDto;
import tss.packagerenewal.gen.APINames;
import tss.packagerenewal.gen.LoggingUtils;

@Transactional
@Service
public class PackageRenewalService {

	static LoggingUtils logger = new LoggingUtils(PackageRenewalService.class.getName());
	EVRBean bean = new EVRBean();
	@Autowired
	PackageRenewalRepository packageRenewalRepository;
	@Autowired
	@PersistenceContext
	private EntityManager em;
	int updateSuccess = 0;
	int subscriptionTypePostpaid = 1;
	
	Session session = null;
	


	
	List<Object[]> batchList = new ArrayList<>();

	List<Object[]> batchList0 = new ArrayList<>();

	List<Object[]> batchList1 = new ArrayList<>();
	List<Object[]> batchList2 = new ArrayList<>();
	List<Object[]> batchList3 = new ArrayList<>();
	List<Object[]> batchList4 = new ArrayList<>();
	List<Object[]> batchList5 = new ArrayList<>();
	List<Object[]> batchList6 = new ArrayList<>();
	List<Object[]> batchList7 = new ArrayList<>();
	List<Object[]> batchList8 = new ArrayList<>();
	List<Object[]> batchList9 = new ArrayList<>();
	
	

; // The size of each batch
	@Value("${SCHEDULER_RATE}")
	private String cronExpression;
	
	@Value("${batch_size_for_processing}")
	private Integer batchSize;
	
	private ExecutorService executor = Executors.newFixedThreadPool(10);
	
	private ExecutorService executor2 = Executors.newFixedThreadPool(10);


	@Transactional

	@Scheduled(fixedDelayString = "${SCHEDULER_RATE}") // Get all packageRenewal
	public void CallingQuery() {

		

		executor.submit(() -> executePackageRenewalQuery(0));
		executor.submit(() -> executePackageRenewalQuery(1));
		executor.submit(() -> executePackageRenewalQuery(2));
		executor.submit(() -> executePackageRenewalQuery(3));
		executor.submit(() -> executePackageRenewalQuery(4));
		executor.submit(() -> executePackageRenewalQuery(5));
		executor.submit(() -> executePackageRenewalQuery(6));
		executor.submit(() -> executePackageRenewalQuery(7));
		executor.submit(() -> executePackageRenewalQuery(8));
		executor.submit(() -> executePackageRenewalQuery(9));
		
		
	}

	public void executePackageRenewalQuery(int tableId) {
	long startTime = System.currentTimeMillis();

		// ConcurrentLinkedQueue<Object[]> conData = new ConcurrentLinkedQueue<>();

		int totalRecordsProcessed = 0;
		int currentPage = 0;

		while (true) {
			String queryString = "SELECT RENEW_ID, PACKAGE_ID, SUBSCRIBER_ID, RENEW_COUNT, `STATUS`, TABLE_ID, NODE_ID FROM wdbs_package_renewal "
					+ "WHERE `STATUS` = 1 AND NEXT_PROV_DATE <= SYSDATE() + INTERVAL 5 MINUTE and table_id = " + tableId;
					//+ " and SUBSCRIBER_ID IN (SELECT SUBSCRIBER_ID FROM WDBS_SUBSCRIBER_ACCOUNT_"+ tableId + ") LIMIT "
					//+ (currentPage * batchSize) + ", " + batchSize;

			Query query = em.createNativeQuery(queryString);
			query.setMaxResults(batchSize);
			List<Object[]> batchList = query.getResultList();
			System.out.println("Fetched " + batchList.size() + " records in this batch.");

			if (batchList.isEmpty()) {
				break;
			}

		
				callingProcedure(batchList,tableId,startTime);
				
			

		
		}

		System.out.println("Total records processed: " + totalRecordsProcessed);

	}

	public void  callingProcedure(List<Object[]> obj,int tableId,long startTime) {

		System.out.println("the executor executed this call " + obj.size());
		


		for (Object[] row : obj) {
			
			
			
			PackRenewalProcedureParameters packageRenewalParameters = new PackRenewalProcedureParameters();

			// Set the values from the result row into the PackDTO object
			logger.info("Ftc_renewal_id ::: " + ((BigInteger) row[0]));
			if (((BigInteger) row[0]) != null) {

				packageRenewalParameters.setFtc_renewal_id(((BigInteger) row[0]));
			}
			logger.info("Ftc_package_id ::: " + ((BigInteger) row[1]));
			if (((BigInteger) row[1]) != null) {

				packageRenewalParameters.setFtc_package_id(((BigInteger) row[1]));
			}
			logger.info("Ftc_subscriber_id ::: " + ((BigInteger) row[2]));
			if (((BigInteger) row[2]) != null) {

				packageRenewalParameters.setFtc_subscriber_id(((BigInteger) row[2]));
			}
			logger.info("Ftc_renew_count ::: " + (Integer) row[3]);
			if (((Integer) row[3]) != null) {

				packageRenewalParameters.setFtc_renew_count((Integer) row[3]);
			}
			logger.info("Ftc_renewalStatus ::: " + (Integer) row[4]);
			if (((Integer) row[4]) != null) {

				packageRenewalParameters.setFtc_renewalStatus((Integer) row[4]);
			}

			logger.info("Ftc_table_id ::: " + (String) row[5]);
			if (((String) row[5]) != null) {

				packageRenewalParameters.setFtc_table_id((String) row[5]);
			}

			logger.info("Ftc_nodeId ::: " + (Integer) row[6]);
			if (((Integer) row[6]) != null) {
				packageRenewalParameters.setFtc_nodeId((Integer) row[6]);
			}

			logger.info("Calling the autoPackRenewal ()"); 

			try {
				
				String procedureName = "SubUpdatePackageRenewal_"+tableId;
				logger.error("Call the Before Renewal Procedure ::: ");
				StoredProcedureQuery procQuery = em.createStoredProcedureQuery(procedureName);

				procQuery.registerStoredProcedureParameter(1, String.class, ParameterMode.IN);// nodeId
				procQuery.registerStoredProcedureParameter(2, Integer.class, ParameterMode.IN);// apiCode

				procQuery.registerStoredProcedureParameter(3, BigInteger.class, ParameterMode.IN);// Ftc_renewal_id
				procQuery.registerStoredProcedureParameter(4, BigInteger.class, ParameterMode.IN);// Ftc_package_id
				procQuery.registerStoredProcedureParameter(5, BigInteger.class, ParameterMode.IN);// Ftc_subscriber_id
				procQuery.registerStoredProcedureParameter(6, Integer.class, ParameterMode.IN);// Ftc_renew_count
				procQuery.registerStoredProcedureParameter(7, Integer.class, ParameterMode.IN);// Ftc_renewalStatus
				procQuery.registerStoredProcedureParameter(8, String.class, ParameterMode.IN);// Ftc_table_id
				procQuery.registerStoredProcedureParameter(9, Integer.class, ParameterMode.IN);// Ftc_nodeId

				procQuery.registerStoredProcedureParameter(10, Integer.class, ParameterMode.OUT);
				procQuery.registerStoredProcedureParameter(11, String.class, ParameterMode.OUT);
				procQuery.registerStoredProcedureParameter(12, String.class, ParameterMode.OUT);

				procQuery.registerStoredProcedureParameter(13, BigInteger.class, ParameterMode.OUT);// Ftc_renewal_id
				procQuery.registerStoredProcedureParameter(14, BigInteger.class, ParameterMode.OUT);// Ftc_package_id
				procQuery.registerStoredProcedureParameter(15, BigInteger.class, ParameterMode.OUT);// Ftc_subscriber_id
				procQuery.registerStoredProcedureParameter(16, Integer.class, ParameterMode.OUT);// Ftc_renew_count
				procQuery.registerStoredProcedureParameter(17, Integer.class, ParameterMode.OUT);// Ftc_renewalStatus

				procQuery.registerStoredProcedureParameter(18, Integer.class, ParameterMode.OUT);// Ftc_nodeId

				

				String nodeId = "01";
				int apiCode = APINames.API_RENEWAL_SERVICE;
				logger.info("nodeId :::-- " + nodeId);
				if (nodeId != null) {
					procQuery.setParameter(1, nodeId);

				}

				procQuery.setParameter(2, apiCode);
				if (packageRenewalParameters.getFtc_renewal_id() != null) {
					procQuery.setParameter(3, packageRenewalParameters.getFtc_renewal_id());

				}
				if (packageRenewalParameters.getFtc_package_id() != null) {
					procQuery.setParameter(4, packageRenewalParameters.getFtc_package_id());

				}
				if (packageRenewalParameters.getFtc_subscriber_id() != null) {
					procQuery.setParameter(5, packageRenewalParameters.getFtc_subscriber_id());

				}

				procQuery.setParameter(6, packageRenewalParameters.getFtc_renew_count());

				procQuery.setParameter(7, packageRenewalParameters.getFtc_renewalStatus());

				if (packageRenewalParameters.getFtc_table_id() != null) {
					procQuery.setParameter(8, packageRenewalParameters.getFtc_table_id());

				}
				logger.info(
						"packageRenewalParameters.getFtc_nodeId() :::-- " + packageRenewalParameters.getFtc_nodeId());
				procQuery.setParameter(9, packageRenewalParameters.getFtc_nodeId());

				// Thread.sleep(1000);

				procQuery.execute();
				// Commit the transaction

				// Getting OUT values from the process Parameters

				Integer ResultDbCode = (Integer) procQuery.getOutputParameterValue(10);
				String DbTxn = (String) procQuery.getOutputParameterValue(11);
				String DbDbLogLog = (String) procQuery.getOutputParameterValue(12);
				logger.info(" procQuery.getOutputParameterValue(13) :::-- " + procQuery.getOutputParameterValue(13));

				BigInteger ftc_renewal_id = (BigInteger) procQuery.getOutputParameterValue(13);
				BigInteger ftc_package_id = (BigInteger) procQuery.getOutputParameterValue(14);
				BigInteger ftc_subscriber_id = (BigInteger) procQuery.getOutputParameterValue(15);
				Integer ftc_renew_count = (Integer) procQuery.getOutputParameterValue(16);
				Integer ftc_renewalStatus = (Integer) procQuery.getOutputParameterValue(17);
				Integer ftc_nodeId = (Integer) procQuery.getOutputParameterValue(18);

				logger.info("ResultDbCode out >>>>>>>>" + ResultDbCode);
				logger.info("DbTxn out >>>>>>>>" + DbTxn);
				logger.info("DbDbLogLog out >>>>>>>>" + DbDbLogLog);

				logger.info("ftc_renewal_id out >>>>>>>>" + ftc_renewal_id);

				logger.info("ftc_package_id out >>>>>>>>" + ftc_package_id);
				logger.info("ftc_subscriber_id out >>>>>>>>" + ftc_subscriber_id);
				logger.info("ftc_renew_count out >>>>>>>>" + ftc_renew_count);
				logger.info("ftc_renewalStatus out >>>>>>>>" + ftc_renewalStatus);
				logger.info("ftc_nodeId out >>>>>>>>" + ftc_nodeId);

				ResponseDto responseDto = new ResponseDto();
				
				
				
				
				;

				responseDto.setTransactionId(DbTxn);
				// responseDto.setSERVICE_END_TIME(renewalEvr.getSERVICE_END_TIME());
				// responseDto.setSERVICE_START_TIME(renewalEvr.getSERVICE_START_TIME());
				if (ftc_package_id != null) {
					responseDto.setPackageId(ftc_package_id.intValue());// Done

				}
				if (ftc_subscriber_id != null) {
					responseDto.setSubscriberId(ftc_subscriber_id.longValue());// Done

				}
				if (ftc_renewal_id != null) {
					responseDto.setRenewalCount(BigInteger.valueOf(ftc_renewal_id.intValue()));

				}
				if (ftc_renewalStatus != null) {
					responseDto.setRenewalStatus(ftc_renewalStatus.toString());
				}
				if (ftc_nodeId != null) {
					responseDto.setNodeId(ftc_nodeId);// Done
				}

				responseDto.setSubscriptionType(subscriptionTypePostpaid);// Done

				responseDto.setApiCode(apiCode);
				
				//result code
				responseDto.setResultCode(ResultDbCode);
				// renew count 
				responseDto.setRenewalCount(BigInteger.valueOf(ftc_renew_count+1));

				
				logger.error("Call GenerateEVR inside the Renewal Procedure ::: ");
				GenerateEVR(responseDto, apiCode); // Call the EVR geneartion
				long endTime=System.currentTimeMillis();
				
				long rtt= endTime-startTime;
				
				logger.info("RTT TIME STAMP "+rtt);
				


			} catch (Exception e) {
				System.out.println("the exception is " + e.getMessage());
			}

		}
	
	}

	
	public void GenerateEVR(ResponseDto response, int apiCode) {
		logger.error("Entering the ever generation method->GenerateEVR");

		System.out.println("Setting apiCode:" + apiCode);
		bean.setAPI_CODE(apiCode);

		bean.setTIMESTAMP(LocalDateTime.now());

		bean.setSUBSCRIPTION_TYPE((long) response.getSubscriptionType());

		if (response.getSubscriberId() != null) {
			bean.setSUBSCRIBER_ID(response.getSubscriberId());
		}
		if (response.getPackageId() != null) {
			bean.setPACKAGE_ID(response.getPackageId());
		}

		bean.setNODE_ID(response.getNodeId());

		if (response.getActualCommUsedRef() != null) {
			bean.setACTUAL_COMM_USED_REF(response.getActualCommUsedRef());
		}

		if (response.getTotalCommAccounted() != null) {
			bean.setTOTAL_COMM_ACCOUNTED(response.getTotalCommAccounted());
			;
		}

		bean.setTIMESTAMP(LocalDateTime.now());

		if (response.getTransactionId() != null) {
			bean.setTRANSACTION_ID(response.getTransactionId());
		}

		if(response.getResultCode()==0){
			 bean.setRESERVED_2("2001"+"-"+response.getRenewalCount()); 
		}
		if(response.getResultCode()==null) {
			bean.setRESERVED_2("5012");
		}
		System.out.println("============================================================="+response.getRenewalCount());
		
		 System.out.println("bean.getRESERVED_2() :: "+bean.getRESERVED_2());

	
		System.out.println("Evr file has been called");

		EvrService.getSingleTonEvrServiceObj().writeEvr(bean);
		System.out.println("Evr has been generated ");

	}

}
