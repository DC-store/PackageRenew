package tss.packagerenewal.Services;

import org.springframework.beans.BeanUtils;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import tss.packagerenewal.Model.EVRBean;
import tss.packagerenewal.gen.LoggingUtils;
import tss.packagerenewal.gen.UtilMethod;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.atomic.AtomicLong;

/**
 * This is the Event listener class which processes the EVRWriter service
 * request upon assigning the EVRBean.
 *
 * 
 */
@Service
public class EvrService {

	static ConcurrentLinkedQueue<EVRBean> linkedQuue = new ConcurrentLinkedQueue<>();
    String productPath = System.getenv("PRODUCT_CONFIG_PATH");
	 //String productPath = "C:\\Users\\Personal_Drive\\PCRF_Project\\PackageRenewal";
	 
	String FileName = productPath + File.separator + "Package_Renew_Evr.cfg";
	private static LoggingUtils logger = new LoggingUtils((EvrService.class.getName()));
	DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy.MM.dd HH:mm:ss");
	private static AtomicLong sequenceNumber = new AtomicLong(00001L);

	public static long getNextCode() {
		long code = sequenceNumber.getAndIncrement();
		if (code == 99999L) {
			sequenceNumber = new AtomicLong(00001L);
			code = sequenceNumber.getAndIncrement();
			System.out.println("Code >>>>>>>>> " + code);
		}
		return code;
	}

	private static long getFileSizeKiloBytes(File file) {
		return file.length() / 1024;
	}

	long fileCreateStartTime = 0;
	long fileCreateEndTime = 0;
	long diffTime = 0;
	boolean fileCreationFlag = true;
	File file = null;
	String template = "";
	String evrFileName = "";
	String filePath = "";
	short dailyMonthlyFlag;
	String fileExtension = "";
	String fileNameFormat = "";
	long fileWriteInterval = 0;
	short fileWriteIntervalUnit;
	String headerContent = "";
	boolean headerFlag;
	String hostName = "";
	boolean threadIdFlag;
	String delimiter = "";
	String fileIdentifier = "";
	long fileWriterSleepTime;
	long fileWriterFileMaxSize;
	private static EvrService singleTonEvrServiceObj;
	UtilMethod utilMethod = new UtilMethod();
	EVRBean evrBean = null;
	EVRBean evrBeanNull = null;

	// private static EvrService singleTonEvrServiceObj = null;
	static {
		singleTonEvrServiceObj = new EvrService();
	}

	public static EvrService getSingleTonEvrServiceObj() {
		return singleTonEvrServiceObj;
	}

	private EvrService() {
		try {
			getTemplate();
		} catch (Exception e) {
			logger.warn("getTemplate() - : Exception while getting EVRTemplate=" + e + ";");
		}
	}

	public void getTemplate() throws Exception {
		logger.info("getTemplate() :");
		System.out.println("FileName Anish   :" + FileName);
		// Reading EVR format template
		try {
			template = utilMethod.readVal(FileName, "WDBS_EVR_FORMAT");
			logger.info("evrTemplate template=>" + template);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrTemplate:" + e);
		}
		// Reading fileName
		try {
			evrFileName = utilMethod.readVal(FileName, "WDBS_EVR_FILE_NAME");
			logger.info("evrFileName fileName=>" + evrFileName);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileName:" + e);
		}
		// Reading EVR file name format
		try {
			fileNameFormat = utilMethod.readVal(FileName, "WDBS_EVR_FILE_NAME_FORMAT");
			logger.info("evrFileNameFormat fileNameFormat=>" + fileNameFormat);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileNameFormat:" + e);
		}
		// Reading EVR file extension
		try {
			fileExtension = utilMethod.readVal(FileName, "WDBS_EVR_FILE_EXTENSION");
			logger.info("evrFileExtension fileExtension=>" + fileExtension);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileExtension:" + e);
		}
		// Reading delimiter
		try {
			delimiter = utilMethod.readVal(FileName, "WDBS_EVR_DELIMITER");
			logger.info("evrDelimiter delimiter=>" + delimiter);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrDelimiter:" + e);
		}

		// Reading filePath
		try {
			filePath = utilMethod.readVal(FileName, "WDBS_FILE_PATH");
			logger.info("evrFilePath filePath=>" + filePath);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFilePath:" + e);
		}
		// Reading dailyMonthlyFlag
		try {
			dailyMonthlyFlag = Short.parseShort(utilMethod.readVal(FileName, "WDBS_DAILY_MONTHLY_FLAG"));
			logger.info("evrDailyMonthlyFlag dailyMonthlyFlag=>" + dailyMonthlyFlag);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrDailyMonthlyFlag:" + e);
		}
		// Reading fileWriteInterval
		try {
			fileWriteInterval = Long.parseLong((utilMethod.readVal(FileName, "WDBS_FILE_WRITE_INTERVAL")));
			logger.info("evrFileWriteInterval fileWriteInterval=>" + fileWriteInterval);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileWriteInterval:" + e);
		}
		// Reading fileWriteIntervalUnit
		try {
			fileWriteIntervalUnit = Short.parseShort(utilMethod.readVal(FileName, "WDBS_FILE_WRITE_INTERVAL_UNIT"));
			logger.info("evrFileWriteIntervalUnit fileWriteIntervalUnit=>" + fileWriteIntervalUnit);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileWriteIntervalUnit:" + e);
		}
		// Reading headerContent
		try {
			headerContent = utilMethod.readVal(FileName, "WDBS_HEADER_CONTENT");
			logger.info("evrHeaderContent headerContent=>" + headerContent);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrHeaderContent:" + e);
		}
		// Reading headerFlag
		try {
			headerFlag = Boolean.parseBoolean(utilMethod.readVal(FileName, "WDBS_HEADER_FLAG"));
			logger.info("evrHeaderFlag headerFlag=>" + headerFlag);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrHeaderFlag:" + e);
		}
		// Reading hostName
		try {
			hostName = utilMethod.readVal(FileName, "WDBS_HOST_NAME");
			logger.info("evrHostName hostName=>" + hostName);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrHostName:" + e);
		}
		// Reading threadIdFlag
		try {
			threadIdFlag = Boolean.parseBoolean(utilMethod.readVal(FileName, "WDBS_THREAD_ID_FLAG"));
			logger.info("evrThreadIdFlag threadIdFlag=>" + threadIdFlag);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrThreadIdFlag:" + e);
		}

		// Reading fileIdentifier
		try {
			fileIdentifier = utilMethod.readVal(FileName, "WDBS_FILE_IDENTIFIER");
			logger.info("evrFileIdentifier fileIdentifier=>" + fileIdentifier);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileIdentifier:" + e);
		}
		// Reading fileWriterSleepTime
		try {
			fileWriterSleepTime = Long.parseLong(utilMethod.readVal(FileName, "WDBS_FILEWRITER_SLEEPTIME_MILLISECOND"));
			logger.info("evrFileWriterSleepTime fileWriterSleepTime=>" + fileWriterSleepTime);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileWriterSleepTime:" + e);
		}
		// Reading fileWriterSleepTime
		try {
			fileWriterFileMaxSize = Long.parseLong(utilMethod.readVal(FileName, "WDBS_FILEWRITER_FILE_MAX_SIZE"));
			logger.info("evrFileWriterFileMaxSize fileWriterFileMaxSize=>" + fileWriterFileMaxSize);
		} catch (Exception e) {
			logger.warn("EXCEPTION:Reading evrFileWriterFileMaxSize:" + e);
		}
	}

	public String frameDefaultEVRContent(EVRBean evrBean) {

		logger.trace("checkAndFrameDefaultParams() :: Appending the default param values [" + template
				+ "] to the EVR Content");
		String evrDefaultParameters = null;
		LocalDateTime dateTime = LocalDateTime.now();

		evrDefaultParameters = template;

		evrDefaultParameters = evrDefaultParameters.replace("__DATE__", dateTime.format(formatter));

		if (evrBean.getOldMac() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__OldMac__", evrBean.getOldMac());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__OldMac__", "");
		}

		if (evrBean.getNewMac() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__NewMac__", evrBean.getNewMac());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__NewMac__", "");
		}

		if (evrBean.getAddOnName() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__AddOnName__", evrBean.getAddOnName());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__AddOnName__", "");
		}

		if (evrBean.getAddOnValue() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__AddOnValue__", evrBean.getAddOnValue());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__AddOnValue__", "");
		}

		if (evrBean.getMac_Username() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__Mac_Username__", evrBean.getMac_Username());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__Mac_Username__", "");
		}

		if (evrBean.getServiceOperation() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__ServiceOperation__", evrBean.getServiceOperation());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__ServiceOperation__", "");
		}

		if (evrBean.getIncomingData() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__IncomingData__",
					String.valueOf(evrBean.getIncomingData()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__IncomingData__", "");
		}

		if (evrBean.getOutgoingData() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__OutgoingData__",
					String.valueOf(evrBean.getOutgoingData()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__OutgoingData__", "");

		}

		if (evrBean.getServiceNo() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__ServiceNo__", evrBean.getServiceNo());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__ServiceNo__", "");
		}

		if (evrBean.getCityID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CityID__", String.valueOf(evrBean.getCityID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CityID__", "");
		}

		if (evrBean.getDistrictID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__DistrictID__",
					String.valueOf(evrBean.getDistrictID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__DistrictID__", "");
		}

		if (evrBean.getNeighborhoodID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__NeighborhoodID__",
					String.valueOf(evrBean.getNeighborhoodID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__NeighborhoodID__", "");
		}

		if (evrBean.getStreetID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__StreetID__", String.valueOf(evrBean.getStreetID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__StreetID__", "");
		}

		if (evrBean.getCmtsOLTID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CmtsOLTID__",
					String.valueOf(evrBean.getCmtsOLTID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CmtsOLTID__", "");
		}

		if (evrBean.getSecureInternetProfileID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SecureInternetProfileID__",
					String.valueOf(evrBean.getSecureInternetProfileID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SecureInternetProfileID__", "");
		}

		if (evrBean.getIpv4() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__Ipv4__", evrBean.getIpv4());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__Ipv4__", "");
		}

		if (evrBean.getIpv6() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__Ipv6__", evrBean.getIpv6());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__Ipv6__", "");
		}

		if (evrBean.getSEQ_NO() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SEQ_NO__", String.valueOf(evrBean.getSEQ_NO()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SEQ_NO__", "");
		}

		if (evrBean.getSUB_IDENTIFIER() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SUB_IDENTIFIER__", evrBean.getSUB_IDENTIFIER());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SUB_IDENTIFIER__", "");
		}

		if (evrBean.getACCOUNT_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__ACCOUNT_ID__", evrBean.getACCOUNT_ID());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__ACCOUNT_ID__", "");
		}

		if (evrBean.getSUBSCRIBER_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SUBSCRIBER_ID__",
					String.valueOf(evrBean.getSUBSCRIBER_ID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SUBSCRIBER_ID__", "");
		}

		if (evrBean.getIMEI() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__IMEI__", evrBean.getIMEI());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__IMEI__", "");
		}

		if (evrBean.getIMSI() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__IMSI__", evrBean.getIMSI());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__IMSI__", "");
		}

		if (evrBean.getSUBSCRIPTION_TYPE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SUBSCRIPTION_TYPE__",
					String.valueOf(evrBean.getSUBSCRIPTION_TYPE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SUBSCRIPTION_TYPE__", "");
		}

		if (evrBean.getCUSTOMER_TYPE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CUSTOMER_TYPE__", evrBean.getCUSTOMER_TYPE());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CUSTOMER_TYPE__", "");
		}

		if (evrBean.getCOS_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__COS_ID__", evrBean.getCOS_ID());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__COS_ID__", "");
		}

		if (evrBean.getAPPLICATION_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__APPLICATION_ID__",
					String.valueOf(evrBean.getAPPLICATION_ID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__APPLICATION_ID__", "");
		}

		if (evrBean.getCDR_TYPE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CDR_TYPE__", String.valueOf(evrBean.getCDR_TYPE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CDR_TYPE__", "");
		}

		if (evrBean.getTIMESTAMP() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__TIMESTAMP__",
					String.valueOf(evrBean.getTIMESTAMP()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__TIMESTAMP__", "");
		}

		if (evrBean.getSERVICE_START_TIME() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_START_TIME__",
					String.valueOf(evrBean.getSERVICE_START_TIME()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_START_TIME__", "");
		}

		if (evrBean.getSERVICE_END_TIME() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_END_TIME__",
					String.valueOf(evrBean.getSERVICE_END_TIME()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_END_TIME__", "");
		}

		if (evrBean.getSESSION_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SESSION_ID__", evrBean.getSESSION_ID());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SESSION_ID__", "");
		}

		if (evrBean.getSGSN_IP() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SGSN_IP__", evrBean.getSGSN_IP());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SGSN_IP__", "");
		}

		if (evrBean.getSGSN_MCC_MNC() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SGSN_MCC_MNC__", evrBean.getSGSN_MCC_MNC());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SGSN_MCC_MNC__", "");
		}

		if (evrBean.getSGSN_TADIG() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SGSN_TADIG__", evrBean.getSGSN_TADIG());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SGSN_TADIG__", "");
		}

		if (evrBean.getAPN() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__APN__", evrBean.getAPN());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__APN__", "");
		}

		if (evrBean.getLOCATION_ACCESS() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__LOCATION_ACCESS__", evrBean.getLOCATION_ACCESS());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__LOCATION_ACCESS__", "");
		}

		if (evrBean.getACCESS_TYPE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__ACCESS_TYPE__",
					String.valueOf(evrBean.getACCESS_TYPE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__ACCESS_TYPE__", "");
		}

		if (evrBean.getCHARGING_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CHARGING_ID__", evrBean.getCHARGING_ID());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CHARGING_ID__", "");
		}

		if (evrBean.getRATING_GROUP() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__RATING_GROUP__",
					String.valueOf(evrBean.getRATING_GROUP()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__RATING_GROUP__", "");
		}

		if (evrBean.getSERVICE_IDENTIFIER() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_IDENTIFIER__",
					evrBean.getSERVICE_IDENTIFIER());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_IDENTIFIER__", "");
		}

		if (evrBean.getPACKAGE_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__PACKAGE_ID__",
					String.valueOf(evrBean.getPACKAGE_ID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__PACKAGE_ID__", "");
		}

		if (evrBean.getBUCKET_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__BUCKET_ID__", evrBean.getBUCKET_ID());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__BUCKET_ID__", "");
		}

		if (evrBean.getSERVICE_REQ_COUNT() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_REQ_COUNT__",
					String.valueOf(evrBean.getSERVICE_REQ_COUNT()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__SERVICE_REQ_COUNT__", "");
		}

		if (evrBean.getCHARGE_USED() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CHARGE_USED__",
					String.valueOf(evrBean.getCHARGE_USED()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CHARGE_USED__", "");
		}

		if (evrBean.getOTHER_SUB_IDENTIFIER() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__OTHER_SUB_IDENTIFIER__",
					evrBean.getOTHER_SUB_IDENTIFIER());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__OTHER_SUB_IDENTIFIER__", "");
		}

		if (evrBean.getRESULT_CODE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__RESULT_CODE__",
					String.valueOf(evrBean.getRESULT_CODE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__RESULT_CODE__", "");
		}

		if (evrBean.getIN_REFERENCE_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__IN_REFERENCE_ID__", evrBean.getIN_REFERENCE_ID());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__IN_REFERENCE_ID__", "");
		}

		if (evrBean.getDOWNLINK_K_BYTES() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__DOWNLINK_K_BYTES__",
					String.valueOf(evrBean.getDOWNLINK_K_BYTES()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__DOWNLINK_K_BYTES__", "");
		}

		if (evrBean.getUPLINK_K_BYTES() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__UPLINK_K_BYTES__",
					String.valueOf(evrBean.getUPLINK_K_BYTES()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__UPLINK_K_BYTES__", "");
		}

		if (evrBean.getACTUAL_COMM_USED_REF() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__ACTUAL_COMM_USED_REF__",
					evrBean.getACTUAL_COMM_USED_REF());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__ACTUAL_COMM_USED_REF__", "");
		}

		if (evrBean.getTOTAL_COMM_ACCOUNTED() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__TOTAL_COMM_ACCOUNTED__",
					String.valueOf(evrBean.getTOTAL_COMM_ACCOUNTED()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__TOTAL_COMM_ACCOUNTED__", "");
		}

		if (evrBean.getCOMM_TYPE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__COMM_TYPE__",
					String.valueOf(evrBean.getCOMM_TYPE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__COMM_TYPE__", "");
		}

		if (evrBean.getCHARGE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CHARGE__", String.valueOf(evrBean.getCHARGE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CHARGE__", "");
		}

		if (evrBean.getTOTAL_TAX() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__TOTAL_TAX__",
					String.valueOf(evrBean.getTOTAL_TAX()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__TOTAL_TAX__", "");
		}

		if (evrBean.getRESERVED_1() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_1__", evrBean.getRESERVED_1());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_1__", "");
		}

		System.out.println("evrBean.getRESERVED_2() : " + evrBean.getRESERVED_2());
		if (evrBean.getRESERVED_2() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_2__", evrBean.getRESERVED_2());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_2__", "");
		}

		if (evrBean.getRESERVED_3() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_3__", evrBean.getRESERVED_3());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_3__", "");
		}

		if (evrBean.getRESERVED_4() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_4__", evrBean.getRESERVED_4());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__RESERVED_4__", "");
		}
		if (evrBean.getTIME_ZONE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__TIME_ZONE__", evrBean.getTIME_ZONE());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__TIME_ZONE__", "");
		}
		if (evrBean.getAPI_USERNAME() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__API_USERNAME__", evrBean.getAPI_USERNAME());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__API_USERNAME__", "");
		}

		if (evrBean.getNODE_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__NODE_ID__", String.valueOf(evrBean.getNODE_ID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__NODE_ID__", "");
		}

		if (evrBean.getCLIENT_IP_ADDRESS() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__CLIENT_IP_ADDRESS__",
					evrBean.getCLIENT_IP_ADDRESS());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__CLIENT_IP_ADDRESS__", "");
		}
		if (evrBean.getAPI_CODE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__API_CODE__", String.valueOf(evrBean.getAPI_CODE()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__API_CODE__", "");
		}
		if (evrBean.getTRANSACTION_ID() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__TRANSACTION_ID__",
					String.valueOf(evrBean.getTRANSACTION_ID()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__TRANSACTION_ID__", "");
		}
		if (evrBean.getQUOTA_DURATION() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__QUOTA_DURATION__",
					String.valueOf(evrBean.getQUOTA_DURATION()));
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__QUOTA_DURATION__", "");
		}
		if (evrBean.getQUOTA_COUNTER() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__QUOTA_COUNTER__", evrBean.getQUOTA_COUNTER());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__QUOTA_COUNTER__", "");
		}
		if (evrBean.getVALUE() != null) {
			evrDefaultParameters = evrDefaultParameters.replace("__VALUE__", evrBean.getVALUE());
		} else {
			evrDefaultParameters = evrDefaultParameters.replace("__VALUE__", "");
		}

		return evrDefaultParameters;

	}

	public String frameFileNameFormat() {

		logger.trace("frameFileNameFormat() :: Appending the default fileNameFormat values [" + fileNameFormat + "] ");

		String defaultFileName = null;
		defaultFileName = fileNameFormat;

		try {
			defaultFileName = defaultFileName.replace("__DATE__", String.valueOf(java.time.LocalDate.now()));
			logger.info("replacing date :");
		} catch (Exception e) {
			logger.warn("EXCEPTION:replacing date :" + e);
		}

		try {
			defaultFileName = defaultFileName.replace("__HOSTNAME__", hostName);
			logger.info("replacing hostname :");
		} catch (Exception e) {
			logger.warn("EXCEPTION:replacing hostname:" + e);
		}

		try {
			defaultFileName = defaultFileName.replace("__FILE_IDENTIFIER__", fileIdentifier);
			logger.info("replacing fileIdentifier :");
		} catch (Exception e) {
			logger.warn("EXCEPTION:replacing fieldIdentifier:" + e);
		}

		return defaultFileName;
	}

	public void writeEvr(EVRBean bean) {

		logger.info("writeEvr():: Received the request to write the EVR[" + bean + "],file name[" + evrFileName
				+ "] and file path[" + filePath + "]");
		if (bean != null) {

			evrBean = new EVRBean();
			BeanUtils.copyProperties(bean, evrBean);

			linkedQuue.offer(evrBean);
			System.out.println("linkedQuue size..." + linkedQuue.size());

			logger.info("writeEvr() :" + evrBean);

		}
	}

	@Component
	public class RunAfterStartup {
		@EventListener(ApplicationReadyEvent.class)
		public synchronized void fileWriter() throws Exception {
			logger.info("fileWriter() :");
			while (true) {
				if (linkedQuue.size() > 0) {
					for (EVRBean evrBean : linkedQuue) {

						String evrContent = frameDefaultEVRContent(evrBean);

						if (evrContent != null) {
							try {
								String finalFileNameFormat = frameFileNameFormat();

								if (fileCreationFlag) {

									String nameDigits = String.format("%05d", getNextCode());
									System.out.println("nameDigits ->>>>" + nameDigits + "------" + getNextCode());

									String finalFileName = finalFileNameFormat.concat(nameDigits) + fileExtension;
									file = new File(filePath + File.separator + finalFileName);

									System.out.println(
											"-----------------------000000000---------------------------------");
									utilMethod.evrCreateFile(file);
									System.out.println("++++++++++++++++++++++++++++1++++++++++++++++++++");
									fileCreateStartTime = System.currentTimeMillis();
									System.out
											.println("+++++++++++++++++++++++++++++2++++++++++++++++++++++++++++++++");
									utilMethod.evrFileWriter(file, evrContent);
									fileCreationFlag = false;

								} else {

									fileCreateEndTime = System.currentTimeMillis();
									diffTime = fileCreateEndTime - fileCreateStartTime;
									System.out
											.println("+++++++++++++++++++++++++++++3++++++++++++++++++++++++++++++++");

									utilMethod.evrFileWriter(file, evrContent);
									System.out
											.println("+++++++++++++++++++++++++++++4++++++++++++++++++++++++++++++++");
									if ((getFileSizeKiloBytes(file) >= fileWriterFileMaxSize)
											|| (diffTime >= fileWriteInterval)) {
										fileCreationFlag = true;
									}
								}

								linkedQuue.remove(evrBean);
								evrBean = evrBeanNull;
								System.out.println("Remove the final evr bean after serve " + linkedQuue.size());

							} catch (Exception e) {
								logger.warn("EXCEPTION:Writing evrContent:" + e);
							}
						}
					}

				} else {
					// logger.info("Invalid evrBean :" + evrBean);
					try {
						this.wait(fileWriterSleepTime);
					} catch (InterruptedException e) {
						logger.warn("EXCEPTION: fileWriterSleepTime:" + e);
					}
				}
			}
		}
	}
}
